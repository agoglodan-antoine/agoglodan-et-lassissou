<?php $__env->startSection('title', $actualite->titre.' — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:800px;">
    <div class="dash-card">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('actualites.index'),'label' => 'Retour aux actualités']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('actualites.index')),'label' => 'Retour aux actualités']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <?php if($actualite->medias->isNotEmpty()): ?>
        <img src="<?php echo e(asset('storage/'.$actualite->medias->first()->chemin_fichier)); ?>" alt="<?php echo e($actualite->titre); ?>"
             style="width:100%;max-height:380px;object-fit:cover;border-radius:var(--radius-sm);margin-bottom:24px;">
      <?php endif; ?>

      <h1 style="margin-bottom:8px;"><?php echo e($actualite->titre); ?></h1>
      <div class="meta" style="margin-bottom:20px;">
        Par <?php echo e($actualite->auteur->nom); ?> <?php echo e($actualite->auteur->prenom); ?> — <?php echo e($actualite->date_publication->format('d/m/Y')); ?>

      </div>

      <p style="white-space:pre-line;line-height:1.7;"><?php echo e($actualite->contenu); ?></p>

      <?php if($actualite->medias->count() > 1): ?>
        <div class="catalogue-grid" style="margin-top:24px;">
          <?php $__currentLoopData = $actualite->medias->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(asset('storage/'.$media->chemin_fichier)); ?>" style="width:100%;border-radius:var(--radius-sm);">
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $actualite)): ?>
        <div class="dash-actions" style="margin-top:28px;">
          <a href="<?php echo e(route('mon-espace.actualites.edit', $actualite)); ?>" class="btn btn-ghost-dark btn-sm">Modifier</a>
          <form method="POST" action="<?php echo e(route('mon-espace.actualites.destroy', $actualite)); ?>" onsubmit="return confirm('Supprimer cette actualité ?');">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
          </form>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\actualites\show.blade.php ENDPATH**/ ?>