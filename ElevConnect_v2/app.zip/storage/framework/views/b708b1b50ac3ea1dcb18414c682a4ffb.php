<?php $__env->startSection('title', 'Litiges — Administration ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <?php echo $__env->make('admin._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="dash-head">
      <div>
        <h1>Litiges</h1>
        <p>Commandes signalées par l'acheteur après livraison.</p>
      </div>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>

    <?php if($litiges->isEmpty()): ?>
      <div class="empty-state">Aucun litige ouvert. 🎉</div>
    <?php else: ?>
      <?php $__currentLoopData = $litiges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="moderation-card">
          <div style="flex:1;">
            <h4 style="margin-bottom:6px;">Commande #<?php echo e($commande->id_commande); ?> — <?php echo e($commande->annonce->titre); ?></h4>
            <div style="font-size:0.85rem;color:var(--ink-soft);margin-bottom:10px;">
              Acheteur : <?php echo e($commande->acheteur->nom); ?> <?php echo e($commande->acheteur->prenom); ?> —
              Fournisseur : <?php echo e($commande->annonce->auteur->nom); ?> <?php echo e($commande->annonce->auteur->prenom); ?> —
              Montant : <?php echo e(number_format($commande->montant_net_commande, 0, ',', ' ')); ?> FCFA
            </div>
            <?php if($commande->description): ?>
              <p style="font-size:0.88rem;color:var(--ink-soft);margin-bottom:14px;"><b>Motif signalé :</b> <?php echo e($commande->description); ?></p>
            <?php endif; ?>

            <div class="dash-actions">
              <form method="POST" action="<?php echo e(route('admin.litiges.faveur-acheteur', $commande)); ?>" onsubmit="return confirm('Trancher en faveur de l\'acheteur (remboursement) ?');">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger btn-sm">Trancher en faveur de l'acheteur (remboursement)</button>
              </form>
              <form method="POST" action="<?php echo e(route('admin.litiges.faveur-fournisseur', $commande)); ?>" onsubmit="return confirm('Trancher en faveur du fournisseur (versements) ?');">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary btn-sm">Trancher en faveur du fournisseur (versements)</button>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php echo e($litiges->links()); ?>

    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\admin\litiges\index.blade.php ENDPATH**/ ?>