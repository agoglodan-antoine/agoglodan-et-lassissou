<?php $__env->startSection('title', 'Annonces — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Toutes les annonces</h1>
        <p>Animaux, provendes et accessoires publiés par nos fournisseurs, validés par nos administrateurs.</p>
      </div>
    </div>

    <form class="filter-bar" method="GET" action="<?php echo e(route('catalogue.index')); ?>" id="filterForm">
      <div class="form-field">
        <label for="type">Type</label>
        <select id="type" name="type">
          <option value="">Tous types</option>
          <option value="animal" <?php echo e(($filtres['type'] ?? '') === 'animal' ? 'selected' : ''); ?>>Animaux</option>
          <option value="provende" <?php echo e(($filtres['type'] ?? '') === 'provende' ? 'selected' : ''); ?>>Provendes</option>
          <option value="accessoire" <?php echo e(($filtres['type'] ?? '') === 'accessoire' ? 'selected' : ''); ?>>Accessoires</option>
        </select>
      </div>
      <div class="form-field">
        <label for="prix_max">Prix max. (FCFA)</label>
        <input type="number" id="prix_max" name="prix_max" min="0" value="<?php echo e($filtres['prix_max'] ?? ''); ?>">
      </div>
      <div class="form-field">
        <label for="rayon">Rayon (km)</label>
        <select id="rayon" name="rayon">
          <?php $__currentLoopData = [10, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($r); ?>" <?php echo e((int) ($filtres['rayon'] ?? 50) === $r ? 'selected' : ''); ?>><?php echo e($r); ?> km</option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <input type="hidden" name="lat" id="latInput" value="<?php echo e(request('lat')); ?>">
      <input type="hidden" name="lng" id="lngInput" value="<?php echo e(request('lng')); ?>">
      <button type="button" class="btn btn-ghost-dark" id="useLocationBtn">
        <i class="fa-solid fa-location-dot"></i> <?php echo e($geolocalise ? 'Position activée' : 'Autour de moi'); ?>

      </button>
      <button type="submit" class="btn btn-primary">Filtrer</button>
    </form>

    <?php if($annonces->isEmpty()): ?>
      <div class="empty-state">Aucune annonce ne correspond à votre recherche pour le moment.</div>
    <?php else: ?>
      <div class="catalogue-grid">
        <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="catalogue-card">
            <a href="<?php echo e(route('catalogue.show', $annonce->id_annonce)); ?>" style="text-decoration:none;color:inherit;display:block;">
              <img src="<?php echo e($annonce->image_1 ? asset('storage/'.$annonce->image_1) : ''); ?>" alt="<?php echo e($annonce->titre); ?>">
            </a>
            <div class="body">
              <a href="<?php echo e(route('catalogue.show', $annonce->id_annonce)); ?>" style="text-decoration:none;color:inherit;">
                <h4><?php echo e($annonce->titre); ?></h4>
              </a>
              <div class="meta">
                <?php echo e(ucfirst($annonce->type_annonce)); ?> · <?php echo e($annonce->nom); ?> <?php echo e($annonce->prenom); ?>

                <?php if(isset($annonce->distance_km)): ?>
                  · <?php echo e(number_format($annonce->distance_km, 1)); ?> km
                <?php endif; ?>
              </div>
              <div class="price"><?php echo e(number_format($annonce->prix_unitaire, 0, ',', ' ')); ?> FCFA</div>
              <?php if(! auth()->check() || auth()->id() !== $annonce->id_utilisateur): ?>
                <a href="<?php echo e(route('commandes.create', $annonce->id_annonce)); ?>" class="btn btn-primary btn-sm" style="width:100%;text-align:center;justify-content:center;margin-top:10px;">Commander</a>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div style="margin-top:32px;"><?php echo e($annonces->links()); ?></div>
    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('useLocationBtn').addEventListener('click', function(){
  if (!navigator.geolocation) return;
  navigator.geolocation.getCurrentPosition(function(pos){
    document.getElementById('latInput').value = pos.coords.latitude;
    document.getElementById('lngInput').value = pos.coords.longitude;
    document.getElementById('filterForm').submit();
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\catalogue\index.blade.php ENDPATH**/ ?>