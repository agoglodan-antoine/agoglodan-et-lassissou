<?php $__env->startSection('title', 'Actualités — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Actualités</h1>
        <p>Conseils d'élevage, santé animale et consommation locale, partagés par la communauté.</p>
      </div>
      <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->peutPublierActualite()): ?>
          <a href="<?php echo e(route('mon-espace.actualites.create')); ?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Publier une actualité</a>
        <?php endif; ?>
      <?php endif; ?>
    </div>

    <form class="filter-bar" method="GET" action="<?php echo e(route('actualites.index')); ?>">
      <div class="form-field">
        <label for="q">Recherche</label>
        <input type="text" id="q" name="q" placeholder="Mot-clé dans le titre ou le contenu" value="<?php echo e($filtres['q'] ?? ''); ?>">
      </div>
      <div class="form-field">
        <label for="role">Auteur</label>
        <select id="role" name="role">
          <option value="">Tous les rôles</option>
          <option value="eleveur" <?php echo e(($filtres['role'] ?? '') === 'eleveur' ? 'selected' : ''); ?>>Éleveur</option>
          <option value="vendeur_provende" <?php echo e(($filtres['role'] ?? '') === 'vendeur_provende' ? 'selected' : ''); ?>>Vendeur de provende</option>
          <option value="vendeur_accessoire" <?php echo e(($filtres['role'] ?? '') === 'vendeur_accessoire' ? 'selected' : ''); ?>>Vendeur d'accessoires</option>
          <option value="veterinaire" <?php echo e(($filtres['role'] ?? '') === 'veterinaire' ? 'selected' : ''); ?>>Vétérinaire</option>
          <option value="administrateur" <?php echo e(($filtres['role'] ?? '') === 'administrateur' ? 'selected' : ''); ?>>Administration</option>
        </select>
      </div>
      <div class="form-field">
        <label for="tri">Tri</label>
        <select id="tri" name="tri">
          <option value="recent" <?php echo e(($filtres['tri'] ?? 'recent') === 'recent' ? 'selected' : ''); ?>>Plus récentes</option>
          <option value="ancien" <?php echo e(($filtres['tri'] ?? '') === 'ancien' ? 'selected' : ''); ?>>Plus anciennes</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary">Filtrer</button>
    </form>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>

    <?php if($actualites->isEmpty()): ?>
      <div class="empty-state">Aucune actualité publiée pour le moment.</div>
    <?php else: ?>
      <div class="catalogue-grid">
        <?php $__currentLoopData = $actualites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actualite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(route('actualites.show', $actualite)); ?>" style="text-decoration:none;color:inherit;">
            <div class="catalogue-card">
              <?php if($actualite->medias->isNotEmpty()): ?>
                <img src="<?php echo e(asset('storage/'.$actualite->medias->first()->chemin_fichier)); ?>" alt="<?php echo e($actualite->titre); ?>">
              <?php endif; ?>
              <div class="body">
                <h4><?php echo e($actualite->titre); ?></h4>
                <div class="meta">
                  Par <?php echo e($actualite->auteur->nom); ?> <?php echo e($actualite->auteur->prenom); ?> —
                  <?php echo e($actualite->date_publication->format('d/m/Y')); ?>

                </div>
                <p style="font-size:0.88rem;color:var(--ink-soft);"><?php echo e(\Illuminate\Support\Str::limit($actualite->contenu, 100)); ?></p>
              </div>
            </div>
          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div style="margin-top:32px;"><?php echo e($actualites->links()); ?></div>
    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\actualites\index.blade.php ENDPATH**/ ?>