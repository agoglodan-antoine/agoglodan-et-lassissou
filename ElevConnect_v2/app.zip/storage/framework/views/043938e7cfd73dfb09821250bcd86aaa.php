<?php $__env->startSection('title', $utilisateur->nom.' '.$utilisateur->prenom.' — Administration ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:700px;">
    <?php echo $__env->make('admin._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="dash-card">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('mon-espace.admin.utilisateurs.index'),'label' => 'Retour aux utilisateurs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('mon-espace.admin.utilisateurs.index')),'label' => 'Retour aux utilisateurs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>

      <?php if(session('status')): ?>
        <div class="dash-card" style="background:var(--pasture-soft);box-shadow:none;color:var(--pasture-dark);font-weight:600;">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>

      <div class="dash-head" style="margin-bottom:20px;">
        <div>
          <h1 style="font-size:1.5rem;"><?php echo e($utilisateur->nom); ?> <?php echo e($utilisateur->prenom); ?></h1>
          <p><?php echo e(ucfirst(str_replace('_', ' ', $utilisateur->role))); ?> — inscrit le <?php echo e($utilisateur->date_inscription->format('d/m/Y')); ?></p>
        </div>
        <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $utilisateur->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($utilisateur->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
      </div>

      <div class="form-grid" style="margin-bottom:24px;">
        <div class="form-field">
          <label>Email</label>
          <p><b><?php echo e($utilisateur->email); ?></b></p>
        </div>
        <div class="form-field">
          <label>Téléphone</label>
          <p><b><?php echo e($utilisateur->telephone ?? '—'); ?></b></p>
        </div>
        <div class="form-field full">
          <label>Adresse</label>
          <p><b><?php echo e($utilisateur->adresse ?? 'Non renseignée'); ?></b></p>
        </div>
      </div>

      <?php if($profil): ?>
        <h3 style="font-size:1rem;margin-bottom:10px;">Informations spécifiques au rôle</h3>
        <div class="form-grid" style="margin-bottom:24px;">
          <?php $__currentLoopData = $profil->getAttributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $champ => $valeur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(in_array($champ, ['id_utilisateur', 'created_at', 'updated_at', 'deleted_at'])) continue; ?>
            <div class="form-field">
              <label><?php echo e(ucfirst(str_replace('_', ' ', $champ))); ?></label>
              <p><b><?php echo e($valeur ?? '—'); ?></b></p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

      <?php if($utilisateur->role !== 'administrateur'): ?>
        <div class="dash-actions">
          <?php if($utilisateur->statut === 'actif'): ?>
            <form method="POST" action="<?php echo e(route('mon-espace.admin.utilisateurs.suspendre', $utilisateur)); ?>" onsubmit="return confirm('Suspendre ce compte ?');">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-danger">Suspendre</button>
            </form>
          <?php else: ?>
            <form method="POST" action="<?php echo e(route('mon-espace.admin.utilisateurs.reactiver', $utilisateur)); ?>">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-primary">Réactiver</button>
            </form>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\admin\utilisateurs\show.blade.php ENDPATH**/ ?>