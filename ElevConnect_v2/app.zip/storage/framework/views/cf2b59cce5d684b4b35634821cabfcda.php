<?php $__env->startSection('title', 'Modifier mon annonce — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="auth-card" style="max-width:720px;">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('mon-espace.annonces.show', $annonce),'label' => 'Retour au détail de l\'annonce']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('mon-espace.annonces.show', $annonce)),'label' => 'Retour au détail de l\'annonce']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <h1>Modifier mon annonce</h1>
      <p class="sub">Toute modification repasse l'annonce en attente de validation par un administrateur.</p>

      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;">
          <ul style="margin:0;padding-left:18px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('mon-espace.annonces.update', $annonce)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <div class="form-grid">
          <div class="form-field full">
            <label for="titre">Titre de l'annonce</label>
            <input type="text" id="titre" name="titre" value="<?php echo e(old('titre', $annonce->titre)); ?>" required>
          </div>
          <div class="form-field full">
            <label for="description">Description</label>
            <textarea id="description" name="description" rows="4"><?php echo e(old('description', $annonce->description)); ?></textarea>
          </div>
          <div class="form-field">
            <label for="prix_unitaire">Prix unitaire (FCFA)</label>
            <input type="number" step="0.01" min="0" id="prix_unitaire" name="prix_unitaire" value="<?php echo e(old('prix_unitaire', $annonce->prix_unitaire)); ?>" required>
          </div>
          <div class="form-field">
            <label for="quantite">Quantité disponible</label>
            <input type="number" min="1" id="quantite" name="quantite" value="<?php echo e(old('quantite', $annonce->quantite)); ?>" required>
          </div>

          <?php if($annonce->type_annonce === 'animal'): ?>
            <div class="form-field">
              <label for="poids">Poids (kg)</label>
              <input type="number" step="0.01" min="0" id="poids" name="poids" value="<?php echo e(old('poids', $annonce->poids)); ?>" required>
            </div>
            <div class="form-field">
              <label for="mois">Âge (mois)</label>
              <input type="number" min="0" id="mois" name="mois" value="<?php echo e(old('mois', $annonce->mois)); ?>" required>
            </div>
          <?php else: ?>
            <div class="form-field">
              <label for="unite_de_mesure">Unité de mesure</label>
              <select id="unite_de_mesure" name="unite_de_mesure" required>
                <?php $__currentLoopData = ['sac' => 'Sac', 'kg' => 'Kilogramme', 'l' => 'Litre', 'bassine' => 'Bassine', 'autre' => 'Autre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($val); ?>" <?php echo e(old('unite_de_mesure', $annonce->unite_de_mesure) === $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          <?php endif; ?>

          <div class="form-field">
            <label for="etat">Disponibilité</label>
            <select id="etat" name="etat" required>
              <option value="disponible" <?php echo e(old('etat', $annonce->etat) === 'disponible' ? 'selected' : ''); ?>>Disponible</option>
              <option value="stock_epuise" <?php echo e(old('etat', $annonce->etat) === 'stock_epuise' ? 'selected' : ''); ?>>Stock épuisé</option>
            </select>
          </div>

          <div class="form-field">
            <label for="image_1">Remplacer la photo principale</label>
            <?php if($annonce->image_1): ?>
              <img src="<?php echo e(asset('storage/'.$annonce->image_1)); ?>" alt="Photo principale actuelle" style="width:120px;height:90px;object-fit:cover;border-radius:var(--radius-sm);margin-bottom:8px;background:var(--sand);">
            <?php endif; ?>
            <input type="file" id="image_1" name="image_1" accept="image/*" data-max-mb="4">
            <span class="form-hint">Laisser vide pour conserver la photo actuelle.</span>
          </div>
          <div class="form-field">
            <label for="image_2">Remplacer la photo secondaire</label>
            <?php if($annonce->image_2): ?>
              <img src="<?php echo e(asset('storage/'.$annonce->image_2)); ?>" alt="Photo secondaire actuelle" style="width:120px;height:90px;object-fit:cover;border-radius:var(--radius-sm);margin-bottom:8px;background:var(--sand);">
            <?php endif; ?>
            <input type="file" id="image_2" name="image_2" accept="image/*" data-max-mb="4">
          </div>
        </div>

        <h3 style="margin:28px 0 4px;font-size:1.1rem;">Réductions par quantité <span style="font-weight:400;color:var(--ink-soft);font-size:0.85rem;">(facultatif)</span></h3>
        <div id="reductionsWrap"></div>
        <button type="button" class="btn btn-ghost-dark btn-sm" id="addReduction" style="margin-bottom:24px;">+ Ajouter une tranche</button>

        <button type="submit" class="btn btn-primary auth-submit">Enregistrer les modifications</button>
      </form>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function(){
  const wrap = document.getElementById('reductionsWrap');
  const addBtn = document.getElementById('addReduction');
  let i = 0;

  function addRow(values){
    values = values || {};
    const row = document.createElement('div');
    row.className = 'reduction-row';
    row.innerHTML = `
      <div class="form-field">
        <label>Quantité min.</label>
        <input type="number" min="1" name="reductions[${i}][quantite_min]" value="${values.quantite_min ?? ''}">
      </div>
      <div class="form-field">
        <label>Quantité max.</label>
        <input type="number" min="1" name="reductions[${i}][quantite_max]" value="${values.quantite_max ?? ''}">
      </div>
      <div class="form-field">
        <label>Réduction (%)</label>
        <input type="number" min="0" max="100" step="0.1" name="reductions[${i}][pourcentage_reduction]" value="${values.pourcentage_reduction ?? ''}">
      </div>
      <button type="button" class="btn btn-danger btn-sm remove-row"><i class="fa-solid fa-xmark"></i></button>
    `;
    row.querySelector('.remove-row').addEventListener('click', () => row.remove());
    wrap.appendChild(row);
    i++;
  }

  addBtn.addEventListener('click', () => addRow());

  const existing = <?php echo json_encode($reductionsExistantes, 15, 512) ?>;
  existing.forEach(addRow);
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\annonces\edit.blade.php ENDPATH**/ ?>