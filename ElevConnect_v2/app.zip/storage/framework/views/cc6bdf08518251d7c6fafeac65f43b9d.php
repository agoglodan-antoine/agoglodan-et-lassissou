<?php $__env->startSection('title', 'Mes livraisons — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Mes livraisons</h1>
        <p>Suivi de vos livraisons acceptées, de la prise en charge à la remise.</p>
      </div>
      <a href="<?php echo e(route('mon-espace.livraison.proposees')); ?>" class="btn btn-ghost-dark">Voir les livraisons proposées</a>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>

    <div class="dash-card" style="padding:0;">
      <?php if($livraisons->isEmpty()): ?>
        <div class="empty-state">Vous n'avez aucune livraison en cours.</div>
      <?php else: ?>
        <div class="table-responsive">
<table class="dash-table">
          <thead>
            <tr>
              <th>Commande</th>
              <th>Trajet</th>
              <th>Frais nets</th>
              <th>Statut</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $livraisons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livraison): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><b><?php echo e($livraison->commande->annonce->titre); ?></b></td>
                <td style="font-size:0.82rem;"><?php echo e($livraison->adresse_fournisseur); ?> <i class="fa-solid fa-arrow-right"></i> <?php echo e($livraison->adresse_client); ?></td>
                <td><?php echo e(number_format($livraison->montant_net_livraison, 0, ',', ' ')); ?> FCFA</td>
                <td><?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $livraison->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($livraison->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?></td>
                <td>
                  <div class="dash-actions">
                    <a href="<?php echo e(route('mon-espace.livraison.show', $livraison)); ?>" class="btn btn-ghost-dark btn-sm">Voir</a>
                    <?php if($livraison->statut === 'prise_en_charge'): ?>
                      <form method="POST" action="<?php echo e(route('mon-espace.livraison.demarrer', $livraison)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-sm">Démarrer la course</button>
                      </form>
                    <?php endif; ?>
                    <?php if($livraison->statut === 'en_cours' && $livraison->commande->statut !== 'livree'): ?>
                      <form method="POST" action="<?php echo e(route('mon-espace.livraison.livrer', $livraison)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-sm">Livraison terminée</button>
                      </form>
                    <?php endif; ?>
                    <?php if($livraison->statut === 'en_cours' && $livraison->commande->statut === 'livree'): ?>
                      <span class="form-hint">Code QR à montrer à l'acheteur</span>
                    <?php endif; ?>
                    <?php if($livraison->statut === 'terminee'): ?>
                      <span class="form-hint">Réception confirmée par l'acheteur <i class="fa-solid fa-check"></i></span>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
</div>
      <?php endif; ?>
    </div>

    <?php echo e($livraisons->links()); ?>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\livraison\mes-livraisons.blade.php ENDPATH**/ ?>