<?php $__env->startSection('title', 'Commande '.$commande->code_authenticite.' — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:700px;">
    <div class="dash-card">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('mon-espace.commandes.index'),'label' => 'Retour à Mes achats']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('mon-espace.commandes.index')),'label' => 'Retour à Mes achats']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <div class="dash-head" style="margin-bottom:20px;">
        <div>
          <h1 style="font-size:1.5rem;">Commande <?php echo e($commande->code_authenticite); ?></h1>
          <p><?php echo e($commande->annonce->titre); ?></p>
        </div>
        <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $commande->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($commande->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
      </div>

      <?php if(session('status')): ?>
        <div class="dash-card" style="background:var(--pasture-soft);box-shadow:none;color:var(--pasture-dark);font-weight:600;">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="dash-card" style="background:rgba(189,74,30,0.08);box-shadow:none;color:var(--clay-dark);font-weight:600;">
          <?php echo e($errors->first()); ?>

        </div>
      <?php endif; ?>

      <div class="form-grid" style="margin-bottom:24px;">
        <div><b>Quantité :</b> <?php echo e($commande->quantite); ?></div>
        <div><b>Prix unitaire :</b> <?php echo e(number_format($commande->prix_unitaire, 0, ',', ' ')); ?> FCFA</div>
        <div><b>Montant brut :</b> <?php echo e(number_format($commande->montant_total, 0, ',', ' ')); ?> FCFA</div>
        <div><b>Réduction :</b> <?php echo e(number_format($commande->reduction_sur_commande, 0, ',', ' ')); ?> FCFA</div>
        <div style="grid-column:1/-1;font-size:1.1rem;"><b>Montant net payé :</b> <?php echo e(number_format($commande->montant_net_commande, 0, ',', ' ')); ?> FCFA</div>
      </div>

      <?php if($commande->statut === 'en_attente'): ?>
        <a href="<?php echo e(route('paiement.show', $commande)); ?>" class="btn btn-primary">Procéder au paiement</a>
      <?php endif; ?>

      <?php if($commande->livraison): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;margin-bottom:20px;">
          <b>Suivi de la livraison :</b>
          <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $commande->livraison->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($commande->livraison->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
          <?php if($commande->livraison->livreur): ?>
            <div style="margin-top:8px;font-size:0.88rem;color:var(--ink-soft);">
              Livreur : <?php echo e($commande->livraison->livreur->utilisateur->nom ?? ''); ?> <?php echo e($commande->livraison->livreur->utilisateur->prenom ?? ''); ?>

              — Frais nets : <?php echo e(number_format($commande->livraison->montant_net_livraison, 0, ',', ' ')); ?> FCFA
            </div>
          <?php endif; ?>
        </div>
      <?php elseif($commande->estRetraitDirect() && in_array($commande->statut, ['payee', 'en_cours_de_traitement', 'validee'])): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;margin-bottom:20px;">
          <b>Mode de retrait :</b> retrait direct auprès du fournisseur (sans livreur).
        </div>
      <?php endif; ?>

      <?php if(! $commande->estRetraitDirect() && in_array($commande->statut, ['payee', 'en_cours_de_traitement', 'validee', 'en_cours_de_livraison'])): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;">
          <p class="form-hint">
            <i class="fa-solid fa-lock"></i> Au moment de la remise, le livreur affichera un code QR sur son
            téléphone : vous n'aurez qu'à le scanner pour confirmer la réception. Aucune action n'est requise
            pour l'instant.
          </p>
        </div>
      <?php endif; ?>

      <?php if($commande->estRetraitDirect() && $commande->statut === 'validee'): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;">
          <h3 style="font-size:1.05rem;margin-bottom:10px;">Confirmer la réception</h3>
          <p class="form-hint" style="margin-bottom:14px;">
            Votre commande a été validée par le fournisseur. Une fois le produit récupéré
            en main propre, confirmez la réception ci-dessous — aucun code n'est requis
            pour un retrait direct.
          </p>
          <form method="POST" action="<?php echo e(route('mon-espace.commandes.confirmer-reception', $commande)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary btn-sm">J'ai récupéré ma commande</button>
          </form>

          <button type="button" class="btn btn-ghost-dark btn-sm" id="toggleDispute" style="margin-top:14px;">Signaler un problème</button>
          <form method="POST" action="<?php echo e(route('mon-espace.commandes.signaler-probleme', $commande)); ?>" id="disputeForm" style="display:none;margin-top:12px;">
            <?php echo csrf_field(); ?>
            <textarea name="description" rows="3" placeholder="Décrivez le problème rencontré" required style="width:100%;padding:0.7em 1em;border-radius:var(--radius-sm);border:1.5px solid var(--line);margin-bottom:10px;"></textarea>
            <button type="submit" class="btn btn-danger btn-sm">Signaler à ElevConnect</button>
          </form>
        </div>
      <?php endif; ?>

      <?php if(! $commande->estRetraitDirect() && $commande->statut === 'livree'): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;">
          <h3 style="font-size:1.05rem;margin-bottom:10px;">Confirmer la réception</h3>
          <p class="form-hint" style="margin-bottom:14px;">
            Le livreur affiche un code QR sur son téléphone au moment de la remise.
            Cliquez ci-dessous puis scannez ce code pour confirmer que la commande vous a bien été livrée.
          </p>

          <form method="POST" action="<?php echo e(route('mon-espace.commandes.confirmer-reception', $commande)); ?>" id="confirmReceptionForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="code" id="codeAuthenticiteInput">
            <button type="button" class="btn btn-primary btn-sm" id="qrScannerOpen"><i class="fa-solid fa-camera"></i> Confirmer la réception</button>
          </form>

          <button type="button" class="btn btn-ghost-dark btn-sm" id="toggleManualCode" style="margin-top:10px;">Je n'arrive pas à scanner, saisir le code manuellement</button>
          <form method="POST" action="<?php echo e(route('mon-espace.commandes.confirmer-reception', $commande)); ?>" id="manualCodeForm" style="display:none;gap:10px;margin-top:10px;">
            <?php echo csrf_field(); ?>
            <input type="text" name="code" placeholder="Code transmis par le livreur" required style="flex:1;padding:0.6em 1em;border-radius:var(--radius-sm);border:1.5px solid var(--line);">
            <button type="submit" class="btn btn-primary btn-sm">Valider</button>
          </form>

          <div class="qr-modal" id="qrScannerModal" style="display:none;">
            <div class="qr-modal-inner">
              <div class="qr-modal-head">
                <span>Scanner le code du livreur</span>
                <button type="button" id="qrScannerClose" aria-label="Fermer"><i class="fa-solid fa-xmark"></i></button>
              </div>
              <video id="qrScannerVideo" playsinline muted></video>
              <canvas id="qrScannerCanvas" style="display:none;"></canvas>
              <p class="form-hint" id="qrScannerHint" style="margin-top:10px;">Placez le QR code affiché par le livreur devant la caméra.</p>
            </div>
          </div>

          <button type="button" class="btn btn-ghost-dark btn-sm" id="toggleDispute" style="margin-top:14px;">Signaler un problème</button>
          <form method="POST" action="<?php echo e(route('mon-espace.commandes.signaler-probleme', $commande)); ?>" id="disputeForm" style="display:none;margin-top:12px;">
            <?php echo csrf_field(); ?>
            <textarea name="description" rows="3" placeholder="Décrivez le problème rencontré" required style="width:100%;padding:0.7em 1em;border-radius:var(--radius-sm);border:1.5px solid var(--line);margin-bottom:10px;"></textarea>
            <button type="submit" class="btn btn-danger btn-sm">Signaler à ElevConnect</button>
          </form>
        </div>
      <?php endif; ?>

      <?php if($commande->statut === 'confirmee' && ! $commande->note_client_commande): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;">
          <h3 style="font-size:1.05rem;margin-bottom:10px;">Votre avis</h3>
          <form method="POST" action="<?php echo e(route('mon-espace.commandes.noter', $commande)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-field">
              <label>Note du fournisseur (1 à 5)</label>
              <select name="note_client_commande" required>
                <?php for($i = 5; $i >= 1; $i--): ?>
                  <option value="<?php echo e($i); ?>"><?php echo e($i); ?> <?php echo e($i > 1 ? 'étoiles' : 'étoile'); ?></option>
                <?php endfor; ?>
              </select>
            </div>
            <div class="form-field">
              <label>Commentaire (facultatif)</label>
              <textarea name="avis_client_commande" rows="2"></textarea>
            </div>
            <?php if($commande->livraison && $commande->livraison->id_livreur): ?>
              <div class="form-field">
                <label>Note du livreur (1 à 5)</label>
                <select name="note_client_livraison">
                  <option value="">—</option>
                  <?php for($i = 5; $i >= 1; $i--): ?>
                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?> <?php echo e($i > 1 ? 'étoiles' : 'étoile'); ?></option>
                  <?php endfor; ?>
                </select>
              </div>
              <div class="form-field">
                <label>Commentaire sur la livraison (facultatif)</label>
                <textarea name="avis_client_livraison" rows="2"></textarea>
              </div>
            <?php endif; ?>
            <button type="submit" class="btn btn-primary btn-sm">Envoyer mon avis</button>
          </form>
        </div>
      <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('annuler', $commande)): ?>
        <form method="POST" action="<?php echo e(route('mon-espace.commandes.annuler', $commande)); ?>" onsubmit="return confirm('Annuler cette commande ?');" style="margin-top:20px;">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger btn-sm">Annuler la commande</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js"></script>
<script>
  const toggleBtn = document.getElementById('toggleDispute');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', function(){
      const form = document.getElementById('disputeForm');
      form.style.display = form.style.display === 'none' ? 'block' : 'none';
    });
  }

  const toggleManualBtn = document.getElementById('toggleManualCode');
  if (toggleManualBtn) {
    toggleManualBtn.addEventListener('click', function () {
      const form = document.getElementById('manualCodeForm');
      form.style.display = form.style.display === 'none' ? 'flex' : 'none';
    });
  }

  // Scanner de code QR par caméra (API MediaDevices + décodage jsQR) : le
  // clic sur "Confirmer la réception" lance directement la caméra. Le QR
  // scanné est celui affiché par le livreur (jamais celui de l'acheteur
  // lui-même) ; dès qu'un code est détecté, la confirmation est envoyée
  // automatiquement au serveur, qui déchiffre et compare le code réel.
  const qrOpenBtn = document.getElementById('qrScannerOpen');
  if (qrOpenBtn) {
    const qrModal = document.getElementById('qrScannerModal');
    const qrCloseBtn = document.getElementById('qrScannerClose');
    const qrVideo = document.getElementById('qrScannerVideo');
    const qrCanvas = document.getElementById('qrScannerCanvas');
    const qrCtx = qrCanvas.getContext('2d', { willReadFrequently: true });
    const qrHint = document.getElementById('qrScannerHint');
    const codeInput = document.getElementById('codeAuthenticiteInput');
    const confirmForm = document.getElementById('confirmReceptionForm');

    let qrStream = null;
    let qrScanning = false;

    function stopQrScanner() {
      qrScanning = false;
      if (qrStream) {
        qrStream.getTracks().forEach(function (track) { track.stop(); });
        qrStream = null;
      }
      qrModal.style.display = 'none';
    }

    function scanQrFrame() {
      if (!qrScanning) return;

      if (qrVideo.readyState === qrVideo.HAVE_ENOUGH_DATA) {
        qrCanvas.width = qrVideo.videoWidth;
        qrCanvas.height = qrVideo.videoHeight;
        qrCtx.drawImage(qrVideo, 0, 0, qrCanvas.width, qrCanvas.height);

        const imageData = qrCtx.getImageData(0, 0, qrCanvas.width, qrCanvas.height);
        const result = jsQR(imageData.data, imageData.width, imageData.height);

        if (result && result.data) {
          codeInput.value = result.data;
          qrHint.textContent = 'Code détecté, confirmation en cours…';
          setTimeout(function () {
            stopQrScanner();
            confirmForm.submit();
          }, 400);
          return;
        }
      }

      requestAnimationFrame(scanQrFrame);
    }

    qrOpenBtn.addEventListener('click', async function () {
      qrModal.style.display = 'flex';

      if (typeof jsQR === 'undefined') {
        qrHint.textContent = "Le scanner n'a pas pu se charger. Utilisez la saisie manuelle ci-dessous.";
        return;
      }

      qrHint.textContent = 'Placez le QR code affiché par le livreur devant la caméra.';

      try {
        qrStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        qrVideo.srcObject = qrStream;
        await qrVideo.play();
        qrScanning = true;
        requestAnimationFrame(scanQrFrame);
      } catch (e) {
        qrHint.textContent = "Impossible d'accéder à la caméra. Vérifiez les autorisations, ou utilisez la saisie manuelle ci-dessous.";
      }
    });

    qrCloseBtn.addEventListener('click', stopQrScanner);
  }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\commandes\show.blade.php ENDPATH**/ ?>