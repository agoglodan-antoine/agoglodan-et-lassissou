<?php $__env->startSection('title', 'Mes rendez-vous — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Mes rendez-vous</h1>
        <p>Vos demandes de consultation auprès des vétérinaires.</p>
      </div>
      <a href="<?php echo e(route('veterinaires.index')); ?>" class="btn btn-primary">Trouver un vétérinaire</a>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>

    <div class="dash-card" style="padding:0;">
      <?php if($rdvs->isEmpty()): ?>
        <div class="empty-state">Vous n'avez pas encore de rendez-vous.</div>
      <?php else: ?>
        <div class="table-responsive">
<table class="dash-table">
          <thead>
            <tr><th>Vétérinaire</th><th>Sujet</th><th>Date</th><th>Statut</th><th></th></tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $rdvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>Dr <?php echo e($rdv->veterinaire->utilisateur->nom); ?> <?php echo e($rdv->veterinaire->utilisateur->prenom); ?></td>
                <td><?php echo e($rdv->sujet); ?></td>
                <td><?php echo e($rdv->date_prevue->format('d/m/Y à H:i')); ?></td>
                <td><?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $rdv->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($rdv->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?></td>
                <td>
                  <div class="dash-actions">
                    <a href="<?php echo e(route('mon-espace.rendez-vous.show', $rdv)); ?>" class="btn btn-ghost-dark btn-sm">Voir</a>
                    <?php if(in_array($rdv->statut, ['en_attente', 'confirme'])): ?>
                      <form method="POST" action="<?php echo e(route('mon-espace.rendez-vous.annuler', $rdv)); ?>" onsubmit="return confirm('Annuler ce rendez-vous ?');">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Annuler</button>
                      </form>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
</div>
      <?php endif; ?>
    </div>

    <?php echo e($rdvs->links()); ?>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\rendez-vous\index.blade.php ENDPATH**/ ?>