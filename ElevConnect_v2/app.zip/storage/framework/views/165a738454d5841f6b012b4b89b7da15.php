<?php $__env->startSection('title', $annonce->titre.' — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:800px;">
    <div class="dash-card">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('mon-espace.annonces.index'),'label' => 'Retour à Mon catalogue']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('mon-espace.annonces.index')),'label' => 'Retour à Mon catalogue']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>

      <?php if(session('status')): ?>
        <div class="dash-card" style="background:var(--pasture-soft);box-shadow:none;color:var(--pasture-dark);font-weight:600;">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>

      <div class="dash-head" style="margin-bottom:20px;">
        <div>
          <h1 style="font-size:1.5rem;"><?php echo e($annonce->titre); ?></h1>
          <p><?php echo e(ucfirst($annonce->type_annonce)); ?> — publiée le <?php echo e($annonce->date_publication->format('d/m/Y')); ?></p>
        </div>
        <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $annonce->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($annonce->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
      </div>

      <?php if($annonce->statut === 'rejetee' && $annonce->motif_rejet): ?>
        <div class="dash-card" style="background:rgba(189,74,30,0.08);box-shadow:none;color:var(--clay-dark);font-weight:600;">
          Motif du rejet : <?php echo e($annonce->motif_rejet); ?>

        </div>
      <?php endif; ?>

      <div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:20px;">
        <?php if($annonce->image_1): ?>
          <img src="<?php echo e(asset('storage/'.$annonce->image_1)); ?>" alt="" style="width:200px;height:150px;object-fit:cover;border-radius:var(--radius-sm);background:var(--sand);">
        <?php endif; ?>
        <?php if($annonce->image_2): ?>
          <img src="<?php echo e(asset('storage/'.$annonce->image_2)); ?>" alt="" style="width:200px;height:150px;object-fit:cover;border-radius:var(--radius-sm);background:var(--sand);">
        <?php endif; ?>
      </div>

      <?php if($annonce->description): ?>
        <p style="color:var(--ink-soft);margin-bottom:20px;"><?php echo e($annonce->description); ?></p>
      <?php endif; ?>

      <div class="form-grid" style="margin-bottom:20px;">
        <div class="form-field">
          <label>Prix unitaire</label>
          <p><b><?php echo e(number_format($annonce->prix_unitaire, 0, ',', ' ')); ?> FCFA</b></p>
        </div>
        <div class="form-field">
          <label>Quantité disponible</label>
          <p><b><?php echo e($annonce->quantite); ?></b></p>
        </div>
        <?php if($annonce->type_annonce === 'animal'): ?>
          <div class="form-field">
            <label>Poids</label>
            <p><b><?php echo e($annonce->poids); ?> kg</b></p>
          </div>
          <div class="form-field">
            <label>Âge</label>
            <p><b><?php echo e($annonce->mois); ?> mois</b></p>
          </div>
        <?php else: ?>
          <div class="form-field">
            <label>Unité de mesure</label>
            <p><b><?php echo e($annonce->unite_de_mesure); ?></b></p>
          </div>
        <?php endif; ?>
        <div class="form-field">
          <label>Disponibilité</label>
          <p><b><?php echo e($annonce->etat === 'disponible' ? 'Disponible' : 'Stock épuisé'); ?></b></p>
        </div>
      </div>

      <?php if($annonce->reductions->isNotEmpty()): ?>
        <h3 style="font-size:1rem;margin-bottom:10px;">Réductions par quantité</h3>
        <div class="table-responsive" style="margin-bottom:20px;">
          <table class="dash-table">
            <thead><tr><th>Quantité min.</th><th>Quantité max.</th><th>Réduction</th></tr></thead>
            <tbody>
              <?php $__currentLoopData = $annonce->reductions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reduction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($reduction->quantite_min); ?></td>
                  <td><?php echo e($reduction->quantite_max); ?></td>
                  <td><?php echo e($reduction->pourcentage_reduction); ?>%</td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

      <div class="dash-actions">
        <a href="<?php echo e(route('mon-espace.annonces.edit', $annonce)); ?>" class="btn btn-primary">Modifier</a>
        <?php if($annonce->statut === 'visible'): ?>
          <a href="<?php echo e(route('catalogue.show', $annonce)); ?>" class="btn btn-ghost-dark">Voir la fiche publique</a>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('mon-espace.annonces.destroy', $annonce)); ?>" onsubmit="return confirm('Supprimer définitivement cette annonce ?');">
          <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <button type="submit" class="btn btn-danger">Supprimer</button>
        </form>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\annonces\show.blade.php ENDPATH**/ ?>