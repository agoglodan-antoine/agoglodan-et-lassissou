<?php $__env->startSection('title', 'Paiement sécurisé — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="auth-card" style="max-width:560px;">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('mon-espace.commandes.show', $commande),'label' => 'Retour à la commande']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('mon-espace.commandes.show', $commande)),'label' => 'Retour à la commande']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <h1>Paiement sécurisé</h1>
      <p class="sub">Commande <?php echo e($commande->code_authenticite); ?> — <?php echo e($commande->annonce->titre); ?></p>

      <div class="dash-card" style="background:var(--sand);box-shadow:none;padding:20px;margin-bottom:24px;">
        <div style="display:flex;justify-content:space-between;">
          <span>Montant à régler</span>
          <b style="font-size:1.2rem;"><?php echo e(number_format($commande->montant_net_commande, 0, ',', ' ')); ?> FCFA</b>
        </div>
      </div>

      <div class="geoloc-status" style="margin-bottom:20px;">
        <i class="fa-solid fa-lock"></i> Ce montant sera détenu en séquestre par ElevConnect et versé au fournisseur
        uniquement après votre confirmation de réception par code QR.
      </div>

      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('paiement.process', $commande)); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-field">
          <label for="moyen_de_paiement">Moyen de paiement</label>
          <select id="moyen_de_paiement" name="moyen_de_paiement" required>
            <option value="mobile_money">Mobile Money</option>
            <option value="carte_bancaire">Carte bancaire</option>
          </select>
        </div>
        <div class="form-field">
          <label for="numero_de_compte">Numéro de compte / téléphone</label>
          <input type="text" id="numero_de_compte" name="numero_de_compte" required placeholder="Ex. 01 00 00 00 00">
        </div>

        <button type="submit" class="btn btn-primary auth-submit">Payer <?php echo e(number_format($commande->montant_net_commande, 0, ',', ' ')); ?> FCFA</button>
      </form>

      <p class="form-hint" style="margin-top:16px;text-align:center;">
        Paiement traité par une passerelle Mobile Money / carte bancaire à intégrer en production.
      </p>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\paiement\show.blade.php ENDPATH**/ ?>