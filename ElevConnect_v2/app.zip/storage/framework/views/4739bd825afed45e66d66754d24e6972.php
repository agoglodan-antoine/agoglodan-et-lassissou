<?php $__env->startSection('title', 'Utilisateurs — Administration ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <?php echo $__env->make('admin._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="dash-head">
      <div>
        <h1>Utilisateurs</h1>
        <p><?php echo e($utilisateurs->total()); ?> compte(s) enregistré(s).</p>
      </div>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>

    <form method="GET" action="<?php echo e(route('mon-espace.admin.utilisateurs.index')); ?>" class="filter-bar">
      <div class="form-field">
        <label>Rôle</label>
        <select name="role">
          <option value="">Tous</option>
          <?php $__currentLoopData = ['eleveur','acheteur','vendeur_provende','vendeur_accessoire','veterinaire','livreur','administrateur']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($r); ?>" <?php echo e(request('role') === $r ? 'selected' : ''); ?>><?php echo e(ucfirst(str_replace('_',' ', $r))); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-field">
        <label>Recherche</label>
        <input type="text" name="recherche" value="<?php echo e(request('recherche')); ?>" placeholder="Nom, prénom, email">
      </div>
      <button type="submit" class="btn btn-primary">Filtrer</button>
    </form>

    <div class="dash-card" style="padding:0;">
      <div class="table-responsive">
<table class="dash-table">
        <thead>
          <tr><th>Nom</th><th>Rôle</th><th>Email</th><th>Statut</th><th>Inscrit le</th><th></th></tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><b><?php echo e($u->nom); ?> <?php echo e($u->prenom); ?></b></td>
              <td><?php echo e(ucfirst(str_replace('_',' ', $u->role))); ?></td>
              <td><?php echo e($u->email); ?></td>
              <td><?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $u->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($u->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?></td>
              <td><?php echo e($u->date_inscription->format('d/m/Y')); ?></td>
              <td>
                <div class="dash-actions">
                  <a href="<?php echo e(route('mon-espace.admin.utilisateurs.show', $u)); ?>" class="btn btn-ghost-dark btn-sm">Voir</a>
                  <?php if($u->role !== 'administrateur'): ?>
                    <?php if($u->statut === 'actif'): ?>
                      <form method="POST" action="<?php echo e(route('mon-espace.admin.utilisateurs.suspendre', $u)); ?>" onsubmit="return confirm('Suspendre ce compte ?');">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Suspendre</button>
                      </form>
                    <?php else: ?>
                      <form method="POST" action="<?php echo e(route('mon-espace.admin.utilisateurs.reactiver', $u)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-sm">Réactiver</button>
                      </form>
                    <?php endif; ?>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>
    </div>

    <?php echo e($utilisateurs->links()); ?>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\admin\utilisateurs\index.blade.php ENDPATH**/ ?>