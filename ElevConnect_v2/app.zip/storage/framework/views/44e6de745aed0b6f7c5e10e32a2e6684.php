<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:28px;">
  <a href="<?php echo e(route('mon-espace.admin.dashboard')); ?>" class="btn <?php echo e(request()->routeIs('mon-espace.admin.dashboard') ? 'btn-primary' : 'btn-ghost-dark'); ?> btn-sm">Vue d'ensemble</a>
  <a href="<?php echo e(route('mon-espace.admin.moderation.index')); ?>" class="btn <?php echo e(request()->routeIs('mon-espace.admin.moderation.*') ? 'btn-primary' : 'btn-ghost-dark'); ?> btn-sm">Modération des annonces</a>
  <a href="<?php echo e(route('mon-espace.admin.utilisateurs.index')); ?>" class="btn <?php echo e(request()->routeIs('mon-espace.admin.utilisateurs.*') ? 'btn-primary' : 'btn-ghost-dark'); ?> btn-sm">Utilisateurs</a>
</div>
<?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\admin\_nav.blade.php ENDPATH**/ ?>