<?php $__env->startSection('title', 'Mes services — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Mes services</h1>
        <p>
          Formule actuelle :
          <b><?php echo e($veterinaire->estPremium() ? 'Premium' : 'Basique'); ?></b>
          <?php if(! $veterinaire->estPremium()): ?>
            (<?php echo e($services->total()); ?>/<?php echo e(config('elevconnect.abonnement_veterinaire.basique.limite_services')); ?> services)
          <?php endif; ?>
          — <a href="<?php echo e(route('mon-espace.abonnement.show')); ?>">gérer mon abonnement</a>
        </p>
      </div>
      <?php if(! $limiteAtteinte): ?>
        <a href="<?php echo e(route('mon-espace.services.create')); ?>" class="btn btn-primary">+ Nouveau service</a>
      <?php else: ?>
        <a href="<?php echo e(route('mon-espace.abonnement.show')); ?>" class="btn btn-primary">Passer en Premium pour en ajouter</a>
      <?php endif; ?>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="dash-card" style="background:rgba(189,74,30,0.08);border:none;color:var(--clay-dark);font-weight:600;">
        <?php echo e($errors->first()); ?>

      </div>
    <?php endif; ?>

    <div class="dash-card" style="padding:0;">
      <?php if($services->isEmpty()): ?>
        <div class="empty-state">
          Vous n'avez encore publié aucun service.
          <br><a href="<?php echo e(route('mon-espace.services.create')); ?>" class="btn btn-ghost-dark" style="margin-top:16px;display:inline-flex;">Publier mon premier service</a>
        </div>
      <?php else: ?>
        <div class="table-responsive">
<table class="dash-table">
          <thead>
            <tr><th>Service</th><th>Prix</th><th>Durée</th><th>Statut</th><th></th></tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><b><?php echo e($service->titre_service); ?></b></td>
                <td><?php echo e(number_format($service->prix, 0, ',', ' ')); ?> FCFA</td>
                <td><?php echo e($service->temps_traitement); ?> min</td>
                <td><?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $service->statut_service]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($service->statut_service)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?></td>
                <td>
                  <div class="dash-actions">
                    <a href="<?php echo e(route('mon-espace.services.show', $service)); ?>" class="btn btn-ghost-dark btn-sm">Voir</a>
                    <a href="<?php echo e(route('mon-espace.services.edit', $service)); ?>" class="btn btn-ghost-dark btn-sm">Modifier</a>
                    <form method="POST" action="<?php echo e(route('mon-espace.services.destroy', $service)); ?>" onsubmit="return confirm('Supprimer ce service ?');">
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
</div>
      <?php endif; ?>
    </div>

    <?php echo e($services->links()); ?>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\services\index.blade.php ENDPATH**/ ?>