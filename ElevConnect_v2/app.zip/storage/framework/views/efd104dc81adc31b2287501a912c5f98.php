<?php $__env->startSection('title', 'Vétérinaires — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Vétérinaires</h1>
        <p>Trouvez un vétérinaire près de chez vous et prenez rendez-vous en ligne.</p>
      </div>
    </div>

    <form class="filter-bar" method="GET" action="<?php echo e(route('veterinaires.index')); ?>" id="filterForm">
      <div class="form-field">
        <label for="specialite">Spécialité</label>
        <input type="text" id="specialite" name="specialite" value="<?php echo e(request('specialite')); ?>" placeholder="Ex. bovins, volailles…">
      </div>
      <input type="hidden" name="lat" id="latInput" value="<?php echo e(request('lat')); ?>">
      <input type="hidden" name="lng" id="lngInput" value="<?php echo e(request('lng')); ?>">
      <button type="button" class="btn btn-ghost-dark" id="useLocationBtn">
        <i class="fa-solid fa-location-dot"></i> <?php echo e($geolocalise ? 'Position activée' : 'Autour de moi'); ?>

      </button>
      <button type="submit" class="btn btn-primary">Rechercher</button>
    </form>

    <?php if($veterinaires->isEmpty()): ?>
      <div class="empty-state">Aucun vétérinaire ne correspond à votre recherche pour le moment.</div>
    <?php else: ?>
      <div class="catalogue-grid">
        <?php $__currentLoopData = $veterinaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(route('veterinaires.show', $vet->id_utilisateur)); ?>" style="text-decoration:none;color:inherit;">
            <div class="catalogue-card">
              <div class="body">
                <?php if($vet->est_premium): ?>
                  <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['force' => 'visible','label' => 'Premium','style' => 'margin-bottom:8px;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['force' => 'visible','label' => 'Premium','style' => 'margin-bottom:8px;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
                <?php endif; ?>
                <h4>Dr <?php echo e($vet->nom); ?> <?php echo e($vet->prenom); ?></h4>
                <div class="meta">
                  <?php echo e($vet->specialite ?? 'Généraliste'); ?>

                  <?php if(isset($vet->distance_km)): ?>
                    · <?php echo e(number_format($vet->distance_km, 1)); ?> km
                  <?php endif; ?>
                </div>
                <?php if($vet->note_moyenne): ?>
                  <div class="price"><i class="fa-solid fa-star"></i> <?php echo e(number_format($vet->note_moyenne, 1)); ?> (<?php echo e($vet->nombre_avis); ?> avis)</div>
                <?php else: ?>
                  <div class="meta">Pas encore d'avis</div>
                <?php endif; ?>
              </div>
            </div>
          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div style="margin-top:32px;"><?php echo e($veterinaires->links()); ?></div>
    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('useLocationBtn').addEventListener('click', function(){
  if (!navigator.geolocation) return;
  navigator.geolocation.getCurrentPosition(function(pos){
    document.getElementById('latInput').value = pos.coords.latitude;
    document.getElementById('lngInput').value = pos.coords.longitude;
    document.getElementById('filterForm').submit();
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\veterinaires\index.blade.php ENDPATH**/ ?>