<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status', 'label' => null, 'force' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status', 'label' => null, 'force' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
  // Classification par défaut d'un statut métier en 3 familles visuelles.
  // Centralise une logique auparavant dupliquée (ternaires / in_array) dans
  // une vingtaine de vues (annonces, commandes, livraisons, services,
  // rendez-vous, versements, utilisateurs...).
  $positifs = ['visible', 'validee', 'confirme', 'confirmee', 'realise', 'terminee', 'actif', 'reussi', 'disponible'];
  $negatifs = ['rejetee', 'annulee', 'annule', 'refusee', 'refuse', 'suspendu', 'expire', 'indisponible', 'en_litige'];

  $classe = $force ?? (
      in_array($status, $positifs, true) ? 'visible'
      : (in_array($status, $negatifs, true) ? 'rejetee' : 'en_attente')
  );

  $texte = $label ?? str_replace('_', ' ', $status);
?>

<span <?php echo e($attributes->merge(['class' => 'status-pill '.$classe])); ?>><?php echo e($texte); ?></span>
<?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\components\status-pill.blade.php ENDPATH**/ ?>