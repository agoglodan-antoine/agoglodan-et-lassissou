<?php $__env->startSection('title', 'Livraison #'.$livraison->id_livraison.' — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:700px;">
    <div class="dash-card">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => $livraison->statut === 'en_attente' ? route('mon-espace.livraison.proposees') : route('mon-espace.livraison.mes'),'label' => $livraison->statut === 'en_attente' ? 'Retour aux livraisons proposées' : 'Retour à mes livraisons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($livraison->statut === 'en_attente' ? route('mon-espace.livraison.proposees') : route('mon-espace.livraison.mes')),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($livraison->statut === 'en_attente' ? 'Retour aux livraisons proposées' : 'Retour à mes livraisons')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>

      <?php if(session('status')): ?>
        <div class="dash-card" style="background:var(--pasture-soft);box-shadow:none;color:var(--pasture-dark);font-weight:600;">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>

      <div class="dash-head" style="margin-bottom:20px;">
        <div>
          <h1 style="font-size:1.5rem;"><?php echo e($livraison->commande->annonce->titre); ?></h1>
          <p><?php echo e($livraison->commande->quantite); ?> unité(s) — commande <?php echo e($livraison->commande->code_authenticite); ?></p>
        </div>
        <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $livraison->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($livraison->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
      </div>

      <div class="form-grid" style="margin-bottom:20px;">
        <div class="form-field full">
          <label>Enlèvement</label>
          <p><b><?php echo e($livraison->adresse_fournisseur); ?></b></p>
        </div>
        <div class="form-field full">
          <label>Livraison</label>
          <p><b><?php echo e($livraison->adresse_client); ?></b></p>
        </div>
        <div class="form-field">
          <label>Acheteur</label>
          <p><b><?php echo e($livraison->commande->acheteur->nom); ?> <?php echo e($livraison->commande->acheteur->prenom); ?></b></p>
        </div>
        <?php if($livraison->montant_net_livraison): ?>
          <div class="form-field">
            <label>Frais nets</label>
            <p><b><?php echo e(number_format($livraison->montant_net_livraison, 0, ',', ' ')); ?> FCFA</b></p>
          </div>
        <?php endif; ?>
      </div>

      <div class="dash-actions">
        <?php if($livraison->statut === 'en_attente'): ?>
          <form method="POST" action="<?php echo e(route('mon-espace.livraison.accepter', $livraison)); ?>" style="display:flex;gap:10px;align-items:flex-end;">
            <?php echo csrf_field(); ?>
            <div class="form-field" style="margin-bottom:0;">
              <label>Vos frais de livraison (FCFA)</label>
              <input type="number" name="frais_de_livraison" min="0" step="50" required style="width:160px;">
            </div>
            <button type="submit" class="btn btn-primary">Accepter</button>
          </form>
          <form method="POST" action="<?php echo e(route('mon-espace.livraison.rejeter', $livraison)); ?>" onsubmit="return confirm('Refuser cette livraison ? Elle sera proposée à un autre livreur disponible.');">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Refuser</button>
          </form>
        <?php endif; ?>

        <?php if($livraison->statut === 'prise_en_charge'): ?>
          <form method="POST" action="<?php echo e(route('mon-espace.livraison.demarrer', $livraison)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Démarrer la course</button>
          </form>
        <?php endif; ?>

        <?php if($livraison->statut === 'en_cours' && $livraison->commande->statut !== 'livree'): ?>
          <form method="POST" action="<?php echo e(route('mon-espace.livraison.livrer', $livraison)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Livraison terminée</button>
          </form>
        <?php endif; ?>

        <?php if($livraison->statut === 'en_cours' && $livraison->commande->statut === 'livree'): ?>
          <span class="form-hint">En attente de la confirmation de l'acheteur.</span>
        <?php endif; ?>

        <?php if($livraison->statut === 'terminee'): ?>
          <span class="form-hint">Réception confirmée par l'acheteur <i class="fa-solid fa-check"></i></span>
        <?php endif; ?>
      </div>

      <?php if($livraison->statut === 'en_cours' && $livraison->commande->statut === 'livree'): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;text-align:center;margin-top:20px;">
          <h3 style="font-size:1.05rem;margin-bottom:6px;">Faites scanner ce code par l'acheteur</h3>
          <p class="form-hint" style="margin-bottom:16px;">
            Montrez cet écran à l'acheteur : il doit le scanner avec son téléphone pour confirmer
            qu'il a bien reçu sa commande. Le code n'est valable que pour cette livraison.
          </p>
          <div style="display:inline-block;padding:16px;background:var(--white);border-radius:var(--radius-sm);">
            <?php echo \SimpleSoftwareIO\QrCode\Facades\QrCode::format('svg')->size(220)->generate(\Illuminate\Support\Facades\Crypt::encryptString($livraison->commande->code_authenticite)); ?>

          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\livraison\show.blade.php ENDPATH**/ ?>