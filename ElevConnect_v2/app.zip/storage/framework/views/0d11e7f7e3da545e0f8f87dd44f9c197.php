<?php $__env->startSection('title', $annonce->titre.' — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:900px;">
    <div class="dash-card">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('catalogue.index'),'label' => 'Retour aux annonces']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('catalogue.index')),'label' => 'Retour aux annonces']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <img src="<?php echo e($annonce->image_1 ? asset('storage/'.$annonce->image_1) : ''); ?>" alt="<?php echo e($annonce->titre); ?>"
           style="width:100%;max-height:420px;object-fit:cover;border-radius:var(--radius-sm);margin-bottom:24px;background:var(--sand);">

      <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['force' => 'visible','label' => ucfirst($annonce->type_annonce),'style' => 'margin-bottom:12px;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['force' => 'visible','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(ucfirst($annonce->type_annonce)),'style' => 'margin-bottom:12px;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
      <h1 style="margin-bottom:8px;"><?php echo e($annonce->titre); ?></h1>
      <div class="price" style="font-size:1.4rem;margin-bottom:20px;"><?php echo e(number_format($annonce->prix_unitaire, 0, ',', ' ')); ?> FCFA</div>

      <?php if($annonce->description): ?>
        <p style="color:var(--ink-soft);margin-bottom:20px;"><?php echo e($annonce->description); ?></p>
      <?php endif; ?>

      <div class="form-grid" style="margin-bottom:20px;">
        <?php if($annonce->type_annonce === 'animal'): ?>
          <div><b>Poids :</b> <?php echo e($annonce->poids); ?> kg</div>
          <div><b>Âge :</b> <?php echo e($annonce->mois); ?> mois</div>
        <?php else: ?>
          <div><b>Unité :</b> <?php echo e($annonce->unite_de_mesure); ?></div>
        <?php endif; ?>
        <div><b>Quantité disponible :</b> <?php echo e($annonce->quantite); ?></div>
        <div><b>Publiée le :</b> <?php echo e($annonce->date_publication->format('d/m/Y')); ?></div>
      </div>

      <?php if($annonce->reductions->isNotEmpty()): ?>
        <h3 style="font-size:1.05rem;margin-bottom:10px;">Réductions par quantité</h3>
        <div class="table-responsive">
        <table class="dash-table" style="margin-bottom:24px;">
          <thead><tr><th>Quantité</th><th>Réduction</th></tr></thead>
          <tbody>
            <?php $__currentLoopData = $annonce->reductions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reduction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($reduction->quantite_min); ?> – <?php echo e($reduction->quantite_max); ?></td>
                <td><?php echo e(rtrim(rtrim(number_format($reduction->pourcentage_reduction, 2), '0'), '.')); ?>%</td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        </div>
      <?php endif; ?>

      <div class="dash-card" style="background:var(--sand);box-shadow:none;">
        <b>Fournisseur :</b> <?php echo e($annonce->auteur->nom); ?> <?php echo e($annonce->auteur->prenom); ?><br>
        <b>Zone :</b> <?php echo e($annonce->auteur->adresse ?? 'Non renseignée'); ?>

      </div>

      <?php if(! auth()->check() || auth()->id() !== $annonce->id_utilisateur): ?>
        <a href="<?php echo e(route('commandes.create', $annonce)); ?>" class="btn btn-primary" style="margin-top:8px;">Commander cette annonce</a>
      <?php else: ?>
        <p class="form-hint" style="margin-top:8px;">Ceci est votre propre annonce.</p>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\catalogue\show.blade.php ENDPATH**/ ?>