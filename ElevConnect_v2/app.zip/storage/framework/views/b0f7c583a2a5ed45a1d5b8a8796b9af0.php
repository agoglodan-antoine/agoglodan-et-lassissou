<?php $__env->startSection('title', 'Dr '.$veterinaire->utilisateur->nom.' — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:800px;">
    <div class="dash-card">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('veterinaires.index'),'label' => 'Retour aux vétérinaires']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('veterinaires.index')),'label' => 'Retour aux vétérinaires']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <div class="dash-head" style="margin-bottom:20px;">
        <div>
          <h1>Dr <?php echo e($veterinaire->utilisateur->nom); ?> <?php echo e($veterinaire->utilisateur->prenom); ?></h1>
          <p><?php echo e($veterinaire->specialite ?? 'Généraliste'); ?> — <?php echo e($veterinaire->zone_intervention ?? 'Zone non renseignée'); ?></p>
          <?php if($veterinaire->note_moyenne): ?>
            <p style="color:var(--clay-dark);font-weight:700;margin-top:6px;"><i class="fa-solid fa-star"></i> <?php echo e(number_format($veterinaire->note_moyenne, 1)); ?> (<?php echo e($veterinaire->nombre_avis); ?> avis)</p>
          <?php endif; ?>
        </div>
        <?php if(auth()->check() && auth()->user()->role !== \App\Models\Utilisateur::ROLE_ELEVEUR): ?>
          <p class="form-hint">Seul un compte Éleveur peut prendre rendez-vous.</p>
        <?php else: ?>
          <a href="<?php echo e(route('rendez-vous.create', $veterinaire)); ?>" class="btn btn-primary">Prendre rendez-vous</a>
        <?php endif; ?>
      </div>

      <h3 style="font-size:1.1rem;margin-bottom:14px;">Services proposés</h3>

      <?php if($veterinaire->services->isEmpty()): ?>
        <p class="form-hint">Aucun service publié pour le moment.</p>
      <?php else: ?>
        <div class="catalogue-grid">
          <?php $__currentLoopData = $veterinaire->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="catalogue-card">
              <img src="<?php echo e($service->photo_illustrative ? asset('storage/'.$service->photo_illustrative) : ''); ?>" alt="<?php echo e($service->titre_service); ?>">
              <div class="body">
                <h4><?php echo e($service->titre_service); ?></h4>
                <div class="meta"><?php echo e($service->temps_traitement); ?> min</div>
                <div class="price"><?php echo e(number_format($service->prix, 0, ',', ' ')); ?> FCFA</div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

      <p class="form-hint" style="margin-top:24px;">
        Le paiement de la consultation se règle directement avec le vétérinaire,
        hors plateforme — ElevConnect facilite uniquement la prise de rendez-vous.
      </p>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\veterinaires\show.blade.php ENDPATH**/ ?>