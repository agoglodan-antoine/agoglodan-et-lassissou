<?php $__env->startSection('title', 'Recherche — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Résultats de recherche</h1>
        <?php if($q !== ''): ?>
          <p><?php echo e($total); ?> résultat(s) pour « <?php echo e($q); ?> »</p>
        <?php else: ?>
          <p>Saisissez un terme à rechercher.</p>
        <?php endif; ?>
      </div>
    </div>

    <?php if($q === ''): ?>
      <div class="empty-state">Utilisez le bouton de recherche dans le menu pour lancer une recherche.</div>
    <?php elseif($total === 0): ?>
      <div class="empty-state">Aucun résultat pour « <?php echo e($q); ?> ». Essayez un autre terme.</div>
    <?php else: ?>

      <?php if($annonces->isNotEmpty()): ?>
        <h3 style="font-size:1.1rem;margin-bottom:14px;">Annonces (<?php echo e($annonces->count()); ?>)</h3>
        <div class="catalogue-grid" style="margin-bottom:36px;">
          <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('catalogue.show', $annonce)); ?>" style="text-decoration:none;color:inherit;">
              <div class="catalogue-card">
                <img src="<?php echo e($annonce->image_1 ? asset('storage/'.$annonce->image_1) : ''); ?>" alt="<?php echo e($annonce->titre); ?>">
                <div class="body">
                  <h4><?php echo e($annonce->titre); ?></h4>
                  <div class="meta"><?php echo e(ucfirst($annonce->type_annonce)); ?> · <?php echo e($annonce->auteur->nom); ?> <?php echo e($annonce->auteur->prenom); ?></div>
                  <div class="price"><?php echo e(number_format($annonce->prix_unitaire, 0, ',', ' ')); ?> FCFA</div>
                </div>
              </div>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

      <?php if($actualites->isNotEmpty()): ?>
        <h3 style="font-size:1.1rem;margin-bottom:14px;">Actualités (<?php echo e($actualites->count()); ?>)</h3>
        <div class="catalogue-grid" style="margin-bottom:36px;">
          <?php $__currentLoopData = $actualites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actualite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('actualites.show', $actualite)); ?>" style="text-decoration:none;color:inherit;">
              <div class="catalogue-card">
                <div class="body">
                  <h4><?php echo e($actualite->titre); ?></h4>
                  <div class="meta">Par <?php echo e($actualite->auteur->nom); ?> <?php echo e($actualite->auteur->prenom); ?></div>
                  <p><?php echo e(\Illuminate\Support\Str::limit($actualite->contenu, 90)); ?></p>
                </div>
              </div>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

      <?php if($services->isNotEmpty()): ?>
        <h3 style="font-size:1.1rem;margin-bottom:14px;">Services vétérinaires (<?php echo e($services->count()); ?>)</h3>
        <div class="catalogue-grid" style="margin-bottom:36px;">
          <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('veterinaires.show', $service->id_veterinaire)); ?>" style="text-decoration:none;color:inherit;">
              <div class="catalogue-card">
                <img src="<?php echo e($service->photo_illustrative ? asset('storage/'.$service->photo_illustrative) : ''); ?>" alt="<?php echo e($service->titre_service); ?>">
                <div class="body">
                  <h4><?php echo e($service->titre_service); ?></h4>
                  <div class="meta">Dr <?php echo e($service->veterinaire->utilisateur->nom); ?> <?php echo e($service->veterinaire->utilisateur->prenom); ?></div>
                  <div class="price"><?php echo e(number_format($service->prix, 0, ',', ' ')); ?> FCFA</div>
                </div>
              </div>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

      <?php if($livreurs->isNotEmpty()): ?>
        <h3 style="font-size:1.1rem;margin-bottom:14px;">Services de transport (<?php echo e($livreurs->count()); ?>)</h3>
        <div class="catalogue-grid" style="margin-bottom:36px;">
          <?php $__currentLoopData = $livreurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livreur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="catalogue-card">
              <div class="body">
                <h4><?php echo e($livreur->utilisateur->nom); ?> <?php echo e($livreur->utilisateur->prenom); ?></h4>
                <div class="meta"><?php echo e($livreur->moyen_transport ?? 'Transport'); ?></div>
                <p>Zone : <?php echo e($livreur->zone_couverture ?? 'Non renseignée'); ?></p>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\recherche\index.blade.php ENDPATH**/ ?>