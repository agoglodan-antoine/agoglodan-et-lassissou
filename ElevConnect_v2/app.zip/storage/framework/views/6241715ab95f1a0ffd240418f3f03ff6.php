<?php $__env->startSection('title', 'Mot de passe oublié — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-section">
  <div class="container">
    <div class="auth-card">
      <h1>Mot de passe oublié</h1>
      <p class="sub">Indiquez votre adresse email : si un compte y est associé, un lien de réinitialisation vous sera envoyé.</p>

      <?php if(session('status')): ?>
        <div class="geoloc-status ok" style="margin-bottom:16px;"><?php echo e(session('status')); ?></div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-field">
          <label for="email">Adresse email</label>
          <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        </div>
        <button type="submit" class="btn btn-primary auth-submit">Envoyer le lien de réinitialisation</button>
      </form>

      <p class="auth-switch"><a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-arrow-left"></i> Retour à la connexion</a></p>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\auth\forgot-password.blade.php ENDPATH**/ ?>