<?php $__env->startSection('title', 'Connexion — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-section">
  <div class="container">
    <div class="auth-card">
      <h1>Connexion</h1>
      <p class="sub">Accédez à votre espace ElevConnect.</p>

      <?php if(session('status')): ?>
        <div class="geoloc-status ok" style="margin-bottom:16px;"><?php echo e(session('status')); ?></div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-field">
          <label for="email">Adresse email</label>
          <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        </div>
        <div class="form-field">
          <label for="password">Mot de passe</label>
          <input type="password" id="password" name="password" required>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
          <label style="display:flex;align-items:center;gap:8px;font-size:0.85rem;color:var(--ink-soft);">
            <input type="checkbox" name="remember"> Se souvenir de moi
          </label>
          <a href="<?php echo e(route('password.request')); ?>" style="font-size:0.85rem;font-weight:700;color:var(--clay-dark);">Mot de passe oublié ?</a>
        </div>
        <button type="submit" class="btn btn-primary auth-submit">Se connecter</button>
      </form>

      <p class="auth-switch">Pas encore de compte ? <a href="<?php echo e(route('register')); ?>">Créer un compte</a></p>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\auth\login.blade.php ENDPATH**/ ?>