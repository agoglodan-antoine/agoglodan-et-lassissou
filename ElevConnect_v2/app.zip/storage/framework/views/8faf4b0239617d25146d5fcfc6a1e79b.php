<?php $__env->startSection('title', 'Mon planning — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Mon planning de disponibilité</h1>
        <p>Déclarez vos créneaux d'indisponibilité : les livraisons ne vous seront pas proposées pendant ces périodes.</p>
      </div>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);box-shadow:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>

    <div class="auth-card" style="max-width:640px;margin:0 0 32px;">
      <h3 style="font-size:1.05rem;margin-bottom:14px;">Ajouter un créneau d'indisponibilité</h3>
      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;">
          <ul style="margin:0;padding-left:18px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
      <form method="POST" action="<?php echo e(route('mon-espace.planning.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-grid">
          <div class="form-field">
            <label>Du</label>
            <input type="datetime-local" name="date_debut" required>
          </div>
          <div class="form-field">
            <label>Au</label>
            <input type="datetime-local" name="date_fin" required>
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Ajouter</button>
      </form>
    </div>

    <div class="dash-card">
      <h3 style="font-size:1.05rem;margin-bottom:14px;">Créneaux déclarés</h3>
      <?php if($creneaux->isEmpty()): ?>
        <p class="form-hint">Aucun créneau d'indisponibilité déclaré — vous êtes considéré disponible en permanence.</p>
      <?php else: ?>
        <div class="table-responsive">
          <table class="dash-table">
            <thead>
              <tr><th>Du</th><th>Au</th><th>Statut</th><th></th></tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $creneaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creneau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($creneau->date_debut->format('d/m/Y H:i')); ?></td>
                  <td><?php echo e($creneau->date_fin->format('d/m/Y H:i')); ?></td>
                  <td>
                    <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['force' => $creneau->date_fin->isPast() ? 'rejetee' : 'en_attente','label' => $creneau->date_fin->isPast() ? 'Passé' : 'Indisponible']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['force' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($creneau->date_fin->isPast() ? 'rejetee' : 'en_attente'),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($creneau->date_fin->isPast() ? 'Passé' : 'Indisponible')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
                  </td>
                  <td>
                    <form method="POST" action="<?php echo e(route('mon-espace.planning.destroy', $creneau)); ?>" onsubmit="return confirm('Supprimer ce créneau ?');">
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\planning\index.blade.php ENDPATH**/ ?>