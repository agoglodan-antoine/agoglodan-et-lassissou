<?php $__env->startSection('title', 'Vérification email — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-section">
  <div class="container">
    <div class="auth-card">
      <h1>Vérification de l'email</h1>
      <p class="sub">
        Merci pour votre inscription ! Avant de commencer, veuillez vérifier votre adresse email 
        en cliquant sur le lien que nous venons de vous envoyer.
      </p>

      <?php if(session('status') == 'verification-link-sent'): ?>
        <div class="geoloc-status ok" style="margin-bottom:16px;">
          Un nouveau lien de vérification a été envoyé à votre adresse email.
        </div>
      <?php endif; ?>

      <div style="display:flex;flex-direction:column;gap:12px;">
        <form method="POST" action="<?php echo e(route('verification.send')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-primary auth-submit" style="width:100%;">
            Renvoyer l'email de vérification
          </button>
        </form>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-secondary auth-submit" style="width:100%;">
            Se déconnecter
          </button>
        </form>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\auth\verify-email.blade.php ENDPATH**/ ?>