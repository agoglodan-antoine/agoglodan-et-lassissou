<?php $__env->startSection('title', 'Rendez-vous — ElevConnect'); ?>

<?php
  $estVeterinaire = auth()->id() === $rendezVous->id_veterinaire;
  $backHref = $estVeterinaire ? route('mon-espace.rendez-vous-recus.index') : route('mon-espace.rendez-vous.index');
  $backLabel = $estVeterinaire ? 'Retour aux rendez-vous reçus' : 'Retour à mes rendez-vous';
?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:700px;">
    <div class="dash-card">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => $backHref,'label' => $backLabel]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($backHref),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($backLabel)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>

      <?php if(session('status')): ?>
        <div class="dash-card" style="background:var(--pasture-soft);box-shadow:none;color:var(--pasture-dark);font-weight:600;">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>

      <div class="dash-head" style="margin-bottom:20px;">
        <div>
          <h1 style="font-size:1.5rem;"><?php echo e($rendezVous->sujet); ?></h1>
          <p><?php echo e($rendezVous->date_prevue->format('d/m/Y à H:i')); ?></p>
        </div>
        <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $rendezVous->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($rendezVous->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
      </div>

      <div class="form-grid" style="margin-bottom:20px;">
        <div class="form-field">
          <label>Éleveur</label>
          <p><b><?php echo e($rendezVous->eleveur->utilisateur->nom); ?> <?php echo e($rendezVous->eleveur->utilisateur->prenom); ?></b></p>
        </div>
        <div class="form-field">
          <label>Vétérinaire</label>
          <p><b>Dr <?php echo e($rendezVous->veterinaire->utilisateur->nom); ?> <?php echo e($rendezVous->veterinaire->utilisateur->prenom); ?></b></p>
        </div>
        <?php if($rendezVous->service): ?>
          <div class="form-field full">
            <label>Service concerné</label>
            <p><b><?php echo e($rendezVous->service->titre_service); ?></b> — <?php echo e(number_format($rendezVous->service->prix, 0, ',', ' ')); ?> FCFA</p>
          </div>
        <?php endif; ?>
      </div>

      <?php if($rendezVous->description): ?>
        <p style="color:var(--ink-soft);margin-bottom:20px;"><?php echo e($rendezVous->description); ?></p>
      <?php endif; ?>

      <p class="form-hint" style="margin-bottom:20px;">Le paiement de la consultation se règle directement avec le vétérinaire, hors plateforme.</p>

      <?php if($rendezVous->note_client): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;">
          <h3 style="font-size:1.05rem;margin-bottom:6px;">Votre avis</h3>
          <p><i class="fa-solid fa-star"></i> <?php echo e($rendezVous->note_client); ?>/5</p>
          <?php if($rendezVous->avis_client): ?>
            <p style="color:var(--ink-soft);"><?php echo e($rendezVous->avis_client); ?></p>
          <?php endif; ?>
        </div>
      <?php elseif(! $estVeterinaire && $rendezVous->statut === 'realise'): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;">
          <h3 style="font-size:1.05rem;margin-bottom:10px;">Votre avis</h3>
          <form method="POST" action="<?php echo e(route('mon-espace.rendez-vous.noter', $rendezVous)); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-field">
              <label>Note du vétérinaire (1 à 5)</label>
              <select name="note_client" required>
                <?php for($i = 5; $i >= 1; $i--): ?>
                  <option value="<?php echo e($i); ?>"><?php echo e($i); ?> <?php echo e($i > 1 ? 'étoiles' : 'étoile'); ?></option>
                <?php endfor; ?>
              </select>
            </div>
            <div class="form-field">
              <label>Commentaire (facultatif)</label>
              <textarea name="avis_client" rows="2"></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-sm">Envoyer mon avis</button>
          </form>
        </div>
      <?php endif; ?>

      <div class="dash-actions">
        <?php if(! $estVeterinaire && in_array($rendezVous->statut, ['en_attente', 'confirme'])): ?>
          <form method="POST" action="<?php echo e(route('mon-espace.rendez-vous.annuler', $rendezVous)); ?>" onsubmit="return confirm('Annuler ce rendez-vous ?');">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Annuler</button>
          </form>
        <?php endif; ?>

        <?php if($estVeterinaire && $rendezVous->statut === 'en_attente'): ?>
          <form method="POST" action="<?php echo e(route('mon-espace.rendez-vous-recus.confirmer', $rendezVous)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Confirmer</button>
          </form>
          <form method="POST" action="<?php echo e(route('mon-espace.rendez-vous-recus.refuser', $rendezVous)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Refuser</button>
          </form>
        <?php endif; ?>

        <?php if($estVeterinaire && $rendezVous->statut === 'confirme'): ?>
          <form method="POST" action="<?php echo e(route('mon-espace.rendez-vous-recus.realise', $rendezVous)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Marquer réalisé</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\rendez-vous\show.blade.php ENDPATH**/ ?>