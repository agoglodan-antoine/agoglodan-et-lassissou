<?php $__env->startSection('title', 'Publier une annonce — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="auth-card" style="max-width:720px;">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('mon-espace.annonces.index'),'label' => 'Retour à Mon catalogue']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('mon-espace.annonces.index')),'label' => 'Retour à Mon catalogue']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <h1>Publier une annonce</h1>
      <p class="sub">
        <?php if($type === 'animal'): ?>
          Votre annonce sera publiée en tant qu'<b>animal</b> et soumise à validation par un administrateur avant d'être visible.
        <?php else: ?>
          Votre annonce sera publiée en tant que <b><?php echo e($type); ?></b> et soumise à validation par un administrateur avant d'être visible.
        <?php endif; ?>
      </p>

      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;">
          <ul style="margin:0;padding-left:18px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('mon-espace.annonces.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-grid">
          <div class="form-field full">
            <label for="titre">Titre de l'annonce</label>
            <input type="text" id="titre" name="titre" value="<?php echo e(old('titre')); ?>" required>
          </div>
          <div class="form-field full">
            <label for="description">Description</label>
            <textarea id="description" name="description" rows="4"><?php echo e(old('description')); ?></textarea>
          </div>
          <div class="form-field">
            <label for="prix_unitaire">Prix unitaire (FCFA)</label>
            <input type="number" step="0.01" min="0" id="prix_unitaire" name="prix_unitaire" value="<?php echo e(old('prix_unitaire')); ?>" required>
          </div>
          <div class="form-field">
            <label for="quantite">Quantité disponible</label>
            <input type="number" min="1" id="quantite" name="quantite" value="<?php echo e(old('quantite', 1)); ?>" required>
          </div>

          <?php if($type === 'animal'): ?>
            <div class="form-field">
              <label for="poids">Poids (kg)</label>
              <input type="number" step="0.01" min="0" id="poids" name="poids" value="<?php echo e(old('poids')); ?>" required>
            </div>
            <div class="form-field">
              <label for="mois">Âge (mois)</label>
              <input type="number" min="0" id="mois" name="mois" value="<?php echo e(old('mois')); ?>" required>
            </div>
          <?php else: ?>
            <div class="form-field">
              <label for="unite_de_mesure">Unité de mesure</label>
              <select id="unite_de_mesure" name="unite_de_mesure" required>
                <option value="sac">Sac</option>
                <option value="kg">Kilogramme</option>
                <option value="l">Litre</option>
                <option value="bassine">Bassine</option>
                <option value="autre">Autre</option>
              </select>
            </div>
          <?php endif; ?>

          <div class="form-field">
            <label for="image_1">Photo principale</label>
            <input type="file" id="image_1" name="image_1" accept="image/*" data-max-mb="4" required>
          </div>
          <div class="form-field">
            <label for="image_2">Photo secondaire (facultatif)</label>
            <input type="file" id="image_2" name="image_2" accept="image/*" data-max-mb="4">
          </div>
        </div>

        <h3 style="margin:28px 0 4px;font-size:1.1rem;">Réductions par quantité <span style="font-weight:400;color:var(--ink-soft);font-size:0.85rem;">(facultatif)</span></h3>
        <p class="form-hint" style="margin-bottom:16px;">Proposez un pourcentage de réduction selon la quantité commandée.</p>

        <div id="reductionsWrap"></div>
        <button type="button" class="btn btn-ghost-dark btn-sm" id="addReduction" style="margin-bottom:24px;">+ Ajouter une tranche</button>

        <button type="submit" class="btn btn-primary auth-submit">Soumettre l'annonce</button>
      </form>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function(){
  const wrap = document.getElementById('reductionsWrap');
  const addBtn = document.getElementById('addReduction');
  let i = 0;

  function addRow(){
    const row = document.createElement('div');
    row.className = 'reduction-row';
    row.innerHTML = `
      <div class="form-field">
        <label>Quantité min.</label>
        <input type="number" min="1" name="reductions[${i}][quantite_min]">
      </div>
      <div class="form-field">
        <label>Quantité max.</label>
        <input type="number" min="1" name="reductions[${i}][quantite_max]">
      </div>
      <div class="form-field">
        <label>Réduction (%)</label>
        <input type="number" min="0" max="100" step="0.1" name="reductions[${i}][pourcentage_reduction]">
      </div>
      <button type="button" class="btn btn-danger btn-sm remove-row"><i class="fa-solid fa-xmark"></i></button>
    `;
    row.querySelector('.remove-row').addEventListener('click', () => row.remove());
    wrap.appendChild(row);
    i++;
  }

  addBtn.addEventListener('click', addRow);
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\annonces\create.blade.php ENDPATH**/ ?>