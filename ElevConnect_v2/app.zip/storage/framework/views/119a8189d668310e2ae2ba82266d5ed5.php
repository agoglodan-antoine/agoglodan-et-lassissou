<?php $__env->startSection('title', 'Mon abonnement — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('mon-espace.dashboard'),'label' => 'Retour au tableau de bord']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('mon-espace.dashboard')),'label' => 'Retour au tableau de bord']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
    <div class="dash-head">
      <div>
        <h1>Mon abonnement</h1>
        <p>Formule actuelle : <b><?php echo e($estPremium ? 'Premium' : 'Basique'); ?></b>
          <?php if($abonnementActif && $estPremium): ?>
            — expire le <?php echo e($abonnementActif->date_expiration->format('d/m/Y')); ?>

          <?php endif; ?>
        </p>
      </div>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="dash-card" style="background:rgba(189,74,30,0.08);border:none;color:var(--clay-dark);font-weight:600;">
        <?php echo e($errors->first()); ?>

      </div>
    <?php endif; ?>

    <div class="pricing-grid" style="margin-bottom:32px;">
      <div class="price-card">
        <h3>Basique</h3>
        <p class="price-desc" style="color:var(--ink-soft);margin-top:6px;">
          Jusqu'à <?php echo e(config('elevconnect.abonnement_veterinaire.basique.limite_services')); ?> services actifs
        </p>
        <div class="price-amount">Gratuit</div>
        <?php if(! $estPremium): ?>
          <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['force' => 'visible','label' => 'Formule actuelle','style' => 'margin-top:20px;display:inline-block;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['force' => 'visible','label' => 'Formule actuelle','style' => 'margin-top:20px;display:inline-block;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
        <?php else: ?>
          <form method="POST" action="<?php echo e(route('mon-espace.abonnement.souscrire')); ?>" style="margin-top:20px;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="formule" value="basique">
            <button type="submit" class="btn btn-ghost-dark">Revenir au Basique</button>
          </form>
        <?php endif; ?>
      </div>

      <div class="price-card premium">
        <span class="plan-badge">Recommandé</span>
        <h3>Premium</h3>
        <p class="price-desc">Services illimités, mise en avant, statistiques</p>
        <div class="price-amount">2 000 FCFA<sub>/mois</sub></div>

        <?php if($estPremium): ?>
          <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['force' => 'visible','label' => 'Formule actuelle','style' => 'margin-top:20px;display:inline-block;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['force' => 'visible','label' => 'Formule actuelle','style' => 'margin-top:20px;display:inline-block;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
        <?php else: ?>
          <button type="button" class="btn btn-primary" id="showPremiumForm" style="margin-top:20px;">Passer en Premium</button>
        <?php endif; ?>
      </div>
    </div>

    <?php if(! $estPremium): ?>
      <div class="auth-card" id="premiumForm" style="display:none;max-width:480px;">
        <h3 style="font-size:1.1rem;margin-bottom:16px;">Paiement de l'abonnement Premium</h3>
        <form method="POST" action="<?php echo e(route('mon-espace.abonnement.souscrire')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="formule" value="premium">
          <div class="form-field">
            <label for="moyen_de_paiement">Moyen de paiement</label>
            <select id="moyen_de_paiement" name="moyen_de_paiement" required>
              <option value="mobile_money">Mobile Money</option>
              <option value="carte_bancaire">Carte bancaire</option>
            </select>
          </div>
          <div class="form-field">
            <label for="numero_de_compte">Numéro de compte / téléphone</label>
            <input type="text" id="numero_de_compte" name="numero_de_compte" required>
          </div>
          <button type="submit" class="btn btn-primary auth-submit">Payer 2 000 FCFA</button>
        </form>
      </div>
    <?php endif; ?>

    <?php if($historique->isNotEmpty()): ?>
      <h3 style="font-size:1.1rem;margin:32px 0 14px;">Historique</h3>
      <div class="dash-card" style="padding:0;">
        <div class="table-responsive">
<table class="dash-table">
          <thead><tr><th>Formule</th><th>Début</th><th>Expiration</th><th>Statut</th></tr></thead>
          <tbody>
            <?php $__currentLoopData = $historique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(ucfirst($ab->formule)); ?></td>
                <td><?php echo e($ab->date_debut->format('d/m/Y')); ?></td>
                <td><?php echo e($ab->date_expiration->format('d/m/Y')); ?></td>
                <td><?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $ab->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ab->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
</div>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  const btn = document.getElementById('showPremiumForm');
  if (btn) {
    btn.addEventListener('click', function(){
      document.getElementById('premiumForm').style.display = 'block';
      btn.style.display = 'none';
    });
  }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\abonnement\show.blade.php ENDPATH**/ ?>