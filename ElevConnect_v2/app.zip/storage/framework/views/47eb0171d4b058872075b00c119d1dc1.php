<?php $__env->startSection('title', 'Commandes reçues — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Commandes reçues</h1>
        <p>Traitez les commandes payées sur vos annonces, jusqu'à leur validation pour livraison.</p>
      </div>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="dash-card" style="background:rgba(189,74,30,0.08);border:none;color:var(--clay-dark);font-weight:600;">
        <?php echo e($errors->first()); ?>

      </div>
    <?php endif; ?>

    <?php if($commandes->isEmpty()): ?>
      <div class="empty-state">Aucune commande à traiter pour le moment.</div>
    <?php else: ?>
      <?php $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="moderation-card">
          <div style="flex:1;">
            <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $commande->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($commande->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
            <h4 style="margin:8px 0 4px;"><?php echo e($commande->annonce->titre); ?> — <?php echo e($commande->quantite); ?> unité(s)</h4>
            <div style="font-size:0.85rem;color:var(--ink-soft);margin-bottom:14px;">
              Acheteur : <?php echo e($commande->acheteur->nom); ?> <?php echo e($commande->acheteur->prenom); ?> —
              Montant net : <?php echo e(number_format($commande->montant_net_commande, 0, ',', ' ')); ?> FCFA —
              <?php echo e($commande->date_commande->format('d/m/Y à H:i')); ?>

            </div>

            <div class="dash-actions">
              <a href="<?php echo e(route('mon-espace.commandes-fournisseur.show', $commande)); ?>" class="btn btn-ghost-dark btn-sm">Voir le détail</a>
              <?php if($commande->statut === 'payee'): ?>
                <form method="POST" action="<?php echo e(route('mon-espace.commandes-fournisseur.prendre-en-charge', $commande)); ?>">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-primary btn-sm">Prendre en charge</button>
                </form>
              <?php endif; ?>

              <?php if($commande->statut === 'en_cours_de_traitement'): ?>
                <form method="POST" action="<?php echo e(route('mon-espace.commandes-fournisseur.valider', $commande)); ?>">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-primary btn-sm">Valider la commande</button>
                </form>
              <?php endif; ?>

              <?php if(in_array($commande->statut, ['payee', 'en_cours_de_traitement'])): ?>
                <button type="button" class="btn btn-danger btn-sm" onclick="document.getElementById('refuse-<?php echo e($commande->id_commande); ?>').classList.toggle('active-form')">Refuser</button>
              <?php endif; ?>
            </div>

            <?php if(in_array($commande->statut, ['payee', 'en_cours_de_traitement'])): ?>
              <form method="POST" action="<?php echo e(route('mon-espace.commandes-fournisseur.refuser', $commande)); ?>" class="moderation-reject-form" id="refuse-<?php echo e($commande->id_commande); ?>" style="display:none;">
                <?php echo csrf_field(); ?>
                <input type="text" name="motif_de_rejet" placeholder="Motif du refus (obligatoire)" required>
                <button type="submit" class="btn btn-danger btn-sm">Confirmer le refus</button>
              </form>
            <?php endif; ?>

            <?php if($commande->statut === 'validee'): ?>
              <p class="form-hint" style="margin-top:8px;">
                Commande validée — en attente d'affectation à un livreur (module Livraison, Phase 4).
              </p>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php echo e($commandes->links()); ?>

    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  // Affiche le mini-formulaire de refus au clic sur "Refuser".
  document.querySelectorAll('[id^="refuse-"]').forEach(form => {
    form.classList.add('js-toggle-target');
  });
  document.addEventListener('click', function(e){
    if (e.target.matches('.btn-danger[onclick]')) return; // géré inline ci-dessus
  });
  document.querySelectorAll('.moderation-reject-form').forEach(f => {
    // rétablit l'affichage flex quand la classe active-form est ajoutée
    const observer = new MutationObserver(() => {
      f.style.display = f.classList.contains('active-form') ? 'flex' : 'none';
    });
    observer.observe(f, { attributes: true, attributeFilter: ['class'] });
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\commandes\fournisseur-index.blade.php ENDPATH**/ ?>