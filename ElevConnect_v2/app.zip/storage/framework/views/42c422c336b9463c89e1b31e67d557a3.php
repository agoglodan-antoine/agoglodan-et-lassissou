
<a href="<?php echo e($href); ?>" class="back-link">
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M15 19l-7-7 7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
  <?php echo e($label ?? 'Retour'); ?>

</a>
<?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\partials\back-link.blade.php ENDPATH**/ ?>