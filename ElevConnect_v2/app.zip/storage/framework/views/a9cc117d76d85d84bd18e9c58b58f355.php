<?php $__env->startSection('title', 'Réinitialiser le mot de passe — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-section">
  <div class="container">
    <div class="auth-card">
      <h1>Nouveau mot de passe</h1>
      <p class="sub">Choisissez un nouveau mot de passe pour votre compte ElevConnect.</p>

      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('password.update')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo e($token); ?>">
        <div class="form-field">
          <label for="email">Adresse email</label>
          <input type="email" id="email" name="email" value="<?php echo e(old('email', $email)); ?>" required autofocus>
        </div>
        <div class="form-field">
          <label for="password">Nouveau mot de passe</label>
          <input type="password" id="password" name="password" required minlength="8">
          <span class="form-hint">Au moins 8 caractères, avec une lettre et un chiffre.</span>
        </div>
        <div class="form-field">
          <label for="password_confirmation">Confirmation</label>
          <input type="password" id="password_confirmation" name="password_confirmation" required minlength="8">
        </div>
        <button type="submit" class="btn btn-primary auth-submit">Réinitialiser le mot de passe</button>
      </form>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\auth\reset-password.blade.php ENDPATH**/ ?>