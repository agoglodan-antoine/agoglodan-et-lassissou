<?php $__env->startSection('title', 'Commande '.$commande->code_authenticite.' — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:700px;">
    <div class="dash-card">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('mon-espace.commandes-fournisseur.index'),'label' => 'Retour aux commandes reçues']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('mon-espace.commandes-fournisseur.index')),'label' => 'Retour aux commandes reçues']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>

      <?php if(session('status')): ?>
        <div class="dash-card" style="background:var(--pasture-soft);box-shadow:none;color:var(--pasture-dark);font-weight:600;">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="dash-card" style="background:rgba(189,74,30,0.08);box-shadow:none;color:var(--clay-dark);font-weight:600;">
          <?php echo e($errors->first()); ?>

        </div>
      <?php endif; ?>

      <div class="dash-head" style="margin-bottom:20px;">
        <div>
          <h1 style="font-size:1.5rem;">Commande <?php echo e($commande->code_authenticite); ?></h1>
          <p><?php echo e($commande->annonce->titre); ?> — <?php echo e($commande->date_commande->format('d/m/Y à H:i')); ?></p>
        </div>
        <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $commande->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($commande->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
      </div>

      <div class="form-grid" style="margin-bottom:24px;">
        <div class="form-field">
          <label>Acheteur</label>
          <p><b><?php echo e($commande->acheteur->nom); ?> <?php echo e($commande->acheteur->prenom); ?></b></p>
        </div>
        <div class="form-field">
          <label>Quantité</label>
          <p><b><?php echo e($commande->quantite); ?></b></p>
        </div>
        <div class="form-field">
          <label>Montant net</label>
          <p><b><?php echo e(number_format($commande->montant_net_commande, 0, ',', ' ')); ?> FCFA</b></p>
        </div>
        <div class="form-field">
          <label>Mode de retrait</label>
          <p><b><?php echo e($commande->estRetraitDirect() ? 'Retrait direct' : 'Livraison'); ?></b></p>
        </div>
      </div>

      <?php if($commande->livraison): ?>
        <div class="dash-card" style="background:var(--sand);box-shadow:none;margin-bottom:20px;">
          <b>Suivi de la livraison :</b>
          <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $commande->livraison->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($commande->livraison->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
        </div>
      <?php endif; ?>

      <div class="dash-actions">
        <?php if($commande->statut === 'payee'): ?>
          <form method="POST" action="<?php echo e(route('mon-espace.commandes-fournisseur.prendre-en-charge', $commande)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Prendre en charge</button>
          </form>
        <?php endif; ?>

        <?php if($commande->statut === 'en_cours_de_traitement'): ?>
          <form method="POST" action="<?php echo e(route('mon-espace.commandes-fournisseur.valider', $commande)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Valider la commande</button>
          </form>
        <?php endif; ?>

        <?php if(in_array($commande->statut, ['payee', 'en_cours_de_traitement'])): ?>
          <button type="button" class="btn btn-danger" onclick="document.getElementById('refuse-form').classList.toggle('active-form')">Refuser</button>
        <?php endif; ?>
      </div>

      <?php if(in_array($commande->statut, ['payee', 'en_cours_de_traitement'])): ?>
        <form method="POST" action="<?php echo e(route('mon-espace.commandes-fournisseur.refuser', $commande)); ?>" class="moderation-reject-form" id="refuse-form" style="display:none;margin-top:14px;">
          <?php echo csrf_field(); ?>
          <input type="text" name="motif_de_rejet" placeholder="Motif du refus (obligatoire)" required>
          <button type="submit" class="btn btn-danger btn-sm">Confirmer le refus</button>
        </form>
      <?php endif; ?>

      <?php if($commande->statut === 'validee'): ?>
        <p class="form-hint" style="margin-top:14px;">Commande validée.</p>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  const refuseForm = document.getElementById('refuse-form');
  if (refuseForm) {
    const observer = new MutationObserver(() => {
      refuseForm.style.display = refuseForm.classList.contains('active-form') ? 'flex' : 'none';
    });
    observer.observe(refuseForm, { attributes: true, attributeFilter: ['class'] });
  }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\commandes\fournisseur-show.blade.php ENDPATH**/ ?>