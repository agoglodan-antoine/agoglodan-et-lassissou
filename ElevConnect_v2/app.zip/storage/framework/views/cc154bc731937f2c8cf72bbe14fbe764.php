<?php $__env->startSection('title', 'Rendez-vous reçus — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Rendez-vous reçus</h1>
        <p>Confirmez, refusez ou clôturez les demandes des éleveurs.</p>
      </div>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>

    <div class="dash-card" style="padding:0;">
      <?php if($rdvs->isEmpty()): ?>
        <div class="empty-state">Aucune demande de rendez-vous pour le moment.</div>
      <?php else: ?>
        <div class="table-responsive">
<table class="dash-table">
          <thead>
            <tr><th>Éleveur</th><th>Sujet</th><th>Date</th><th>Statut</th><th></th></tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $rdvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($rdv->eleveur->utilisateur->nom); ?> <?php echo e($rdv->eleveur->utilisateur->prenom); ?></td>
                <td><?php echo e($rdv->sujet); ?><?php if($rdv->service): ?> <br><small><?php echo e($rdv->service->titre_service); ?></small><?php endif; ?></td>
                <td><?php echo e($rdv->date_prevue->format('d/m/Y à H:i')); ?></td>
                <td><?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $rdv->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($rdv->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?></td>
                <td>
                  <div class="dash-actions">
                    <a href="<?php echo e(route('mon-espace.rendez-vous.show', $rdv)); ?>" class="btn btn-ghost-dark btn-sm">Voir</a>
                    <?php if($rdv->statut === 'en_attente'): ?>
                      <form method="POST" action="<?php echo e(route('mon-espace.rendez-vous-recus.confirmer', $rdv)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-sm">Confirmer</button>
                      </form>
                      <form method="POST" action="<?php echo e(route('mon-espace.rendez-vous-recus.refuser', $rdv)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Refuser</button>
                      </form>
                    <?php endif; ?>
                    <?php if($rdv->statut === 'confirme'): ?>
                      <form method="POST" action="<?php echo e(route('mon-espace.rendez-vous-recus.realise', $rdv)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-sm">Marquer réalisé</button>
                      </form>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
</div>
      <?php endif; ?>
    </div>

    <?php echo e($rdvs->links()); ?>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\rendez-vous\recus.blade.php ENDPATH**/ ?>