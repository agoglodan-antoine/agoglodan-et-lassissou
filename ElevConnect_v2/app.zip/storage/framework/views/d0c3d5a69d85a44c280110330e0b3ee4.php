<?php $__env->startSection('title', 'Livraisons disponibles — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Livraisons disponibles</h1>
        <p>Commandes validées par leur fournisseur, en attente d'un livreur.</p>
      </div>
      <a href="<?php echo e(route('livraison.mes')); ?>" class="btn btn-ghost-dark">Mes livraisons en cours</a>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="dash-card" style="background:rgba(189,74,30,0.08);border:none;color:var(--clay-dark);font-weight:600;">
        <?php echo e($errors->first()); ?>

      </div>
    <?php endif; ?>

    <?php if($livraisons->isEmpty()): ?>
      <div class="empty-state">Aucune livraison disponible pour le moment.</div>
    <?php else: ?>
      <?php $__currentLoopData = $livraisons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livraison): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="moderation-card">
          <div style="flex:1;">
            <h4 style="margin-bottom:4px;"><?php echo e($livraison->commande->annonce->titre); ?> — <?php echo e($livraison->commande->quantite); ?> unité(s)</h4>
            <div style="font-size:0.85rem;color:var(--ink-soft);margin-bottom:14px;">
              <b>Enlèvement :</b> <?php echo e($livraison->adresse_fournisseur); ?> &nbsp;→&nbsp;
              <b>Livraison :</b> <?php echo e($livraison->adresse_client); ?>

            </div>

            <form method="POST" action="<?php echo e(route('livraison.accepter', $livraison)); ?>" style="display:flex;gap:10px;align-items:flex-end;">
              <?php echo csrf_field(); ?>
              <div class="form-field" style="margin-bottom:0;">
                <label>Vos frais de livraison (FCFA)</label>
                <input type="number" name="frais_de_livraison" min="0" step="50" required style="width:160px;">
              </div>
              <button type="submit" class="btn btn-primary btn-sm">Accepter cette livraison</button>
            </form>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php echo e($livraisons->links()); ?>

    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\livraison\disponibles.blade.php ENDPATH**/ ?>