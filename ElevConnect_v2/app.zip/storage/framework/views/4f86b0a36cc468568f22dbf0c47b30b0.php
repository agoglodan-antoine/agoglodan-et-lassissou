<?php $__env->startSection('title', 'Prendre rendez-vous — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="auth-card" style="max-width:640px;">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('veterinaires.show', $veterinaire),'label' => 'Retour au profil du vétérinaire']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('veterinaires.show', $veterinaire)),'label' => 'Retour au profil du vétérinaire']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <h1>Rendez-vous avec Dr <?php echo e($veterinaire->utilisateur->nom); ?> <?php echo e($veterinaire->utilisateur->prenom); ?></h1>
      <p class="sub">Le paiement de la consultation se règle directement avec le vétérinaire, hors plateforme.</p>

      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('rendez-vous.store', $veterinaire)); ?>">
        <?php echo csrf_field(); ?>

        <?php if($veterinaire->services->isNotEmpty()): ?>
          <div class="form-field">
            <label for="id_service">Service concerné (facultatif)</label>
            <select id="id_service" name="id_service">
              <option value="">Consultation générale</option>
              <?php $__currentLoopData = $veterinaire->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($service->id_service); ?>"><?php echo e($service->titre_service); ?> — <?php echo e(number_format($service->prix, 0, ',', ' ')); ?> FCFA</option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        <?php endif; ?>

        <div class="form-field">
          <label for="sujet">Sujet</label>
          <input type="text" id="sujet" name="sujet" value="<?php echo e(old('sujet')); ?>" required placeholder="Ex. Suspicion de maladie sur un bovin">
        </div>
        <div class="form-field">
          <label for="description">Description</label>
          <textarea id="description" name="description" rows="4"><?php echo e(old('description')); ?></textarea>
        </div>
        <div class="form-field">
          <label for="date_prevue">Date et heure souhaitées</label>
          <input type="datetime-local" id="date_prevue" name="date_prevue" value="<?php echo e(old('date_prevue')); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary auth-submit">Envoyer la demande</button>
      </form>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\rendez-vous\create.blade.php ENDPATH**/ ?>