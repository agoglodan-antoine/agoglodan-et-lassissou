<?php $__env->startSection('title', 'Commander — '.$annonce->titre); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="auth-card" style="max-width:640px;">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('catalogue.show', $annonce),'label' => 'Retour à l\'annonce']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('catalogue.show', $annonce)),'label' => 'Retour à l\'annonce']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <h1>Commander</h1>
      <p class="sub"><?php echo e($annonce->titre); ?> — <?php echo e(number_format($annonce->prix_unitaire, 0, ',', ' ')); ?> FCFA / unité</p>

      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('commandes.store', $annonce)); ?>" id="orderForm">
        <?php echo csrf_field(); ?>
        <div class="form-field">
          <label for="quantite">Quantité (disponible : <?php echo e($annonce->quantite); ?>)</label>
          <input type="number" id="quantite" name="quantite" min="1" max="<?php echo e($annonce->quantite); ?>" value="<?php echo e(old('quantite', 1)); ?>" required>
        </div>

        <div class="form-field">
          <label>Mode de retrait</label>
          <div class="role-picker" style="grid-template-columns:1fr 1fr;">
            <div style="position:relative;">
              <input type="radio" name="mode_reception" id="mode-retrait" value="retrait_direct" checked>
              <label for="mode-retrait">Retrait direct<br><span style="font-weight:400;font-size:0.72rem;">auprès du fournisseur</span></label>
            </div>
            <div style="position:relative;">
              <input type="radio" name="mode_reception" id="mode-livreur" value="livreur" <?php echo e($livreurs->isEmpty() ? 'disabled' : ''); ?>>
              <label for="mode-livreur">Faire livrer<br><span style="font-weight:400;font-size:0.72rem;">par un livreur</span></label>
            </div>
          </div>
        </div>

        <div class="form-field" id="livreurField" style="display:none;">
          <label>Choisir un livreur</label>
          <?php if($livreurs->isEmpty()): ?>
            <p class="form-hint">Aucun livreur n'est actuellement disponible près du fournisseur — seul le retrait direct est possible.</p>
          <?php else: ?>
            <input type="hidden" id="id_livreur" name="id_livreur" value="">
            <button type="button" class="btn btn-ghost-dark" id="openLivreurModal" style="justify-content:flex-start;">
              <i class="fa-solid fa-truck"></i>&nbsp; <span id="livreurChoisiLabel">Sélectionner un livreur…</span>
            </button>
            <span class="form-hint">Triés par proximité avec le fournisseur. Le livreur choisi devra accepter votre livraison ; en cas de refus, elle sera automatiquement proposée à un autre.</span>
          <?php endif; ?>
        </div>

        <?php if (! ($livreurs->isEmpty())): ?>
          <div class="qr-modal" id="livreurModal" style="display:none;">
            <div class="qr-modal-inner" style="max-width:480px;">
              <div class="qr-modal-head">
                <span>Choisir un livreur</span>
                <button type="button" id="closeLivreurModal" aria-label="Fermer"><i class="fa-solid fa-xmark"></i></button>
              </div>
              <input
                type="text"
                id="livreurSearchInput"
                placeholder="Rechercher un livreur par nom…"
                style="width:100%;padding:0.6em 1em;border-radius:var(--radius-sm);border:1.5px solid var(--line);margin-bottom:14px;"
              >
              <div id="livreurResultsList" class="livreur-results"></div>
            </div>
          </div>
        <?php endif; ?>

        <div class="dash-card" style="background:var(--sand);box-shadow:none;padding:20px;margin-top:20px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
            <span>Montant brut</span><b id="montantBrut">—</b>
          </div>
          <div style="display:flex;justify-content:space-between;margin-bottom:8px;color:var(--pasture-dark);">
            <span>Réduction applicable</span><b id="reduction">—</b>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:1.15rem;border-top:1px solid var(--line);padding-top:10px;">
            <span>Total à payer</span><b id="montantNet">—</b>
          </div>
        </div>

        <p class="form-hint" style="margin-top:16px;">
          Le paiement est réglé en ligne sur l'écran suivant. Les fonds resteront détenus
          en séquestre par ElevConnect jusqu'à la confirmation de réception (par vous-même,
          en main propre, ou après scan du code QR si un livreur intervient).
        </p>

        <button type="submit" class="btn btn-primary auth-submit" style="margin-top:8px;">Passer au paiement</button>
      </form>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function(){
  const prixUnitaire = <?php echo e((float) $annonce->prix_unitaire); ?>;
  const tranches = <?php echo json_encode($tranchesReduction, 15, 512) ?>;

  const qteInput = document.getElementById('quantite');
  const brutEl = document.getElementById('montantBrut');
  const reducEl = document.getElementById('reduction');
  const netEl = document.getElementById('montantNet');

  function formatFcfa(n){
    return Math.round(n).toLocaleString('fr-FR') + ' FCFA';
  }

  function recompute(){
    const qte = parseInt(qteInput.value || '0', 10);
    const brut = prixUnitaire * qte;
    const tranche = tranches.find(t => qte >= t.min && qte <= t.max);
    const pct = tranche ? tranche.pct : 0;
    const reduction = brut * (pct / 100);

    brutEl.textContent = formatFcfa(brut);
    reducEl.textContent = pct > 0 ? '- ' + formatFcfa(reduction) + ' (' + pct + '%)' : 'Aucune';
    netEl.textContent = formatFcfa(brut - reduction);
  }

  qteInput.addEventListener('input', recompute);
  recompute();

  // Affiche le choix du livreur uniquement si "Faire livrer" est sélectionné.
  const livreurField = document.getElementById('livreurField');
  const radios = document.querySelectorAll('input[name="mode_reception"]');
  function toggleLivreurField(){
    const mode = document.querySelector('input[name="mode_reception"]:checked').value;
    livreurField.style.display = mode === 'livreur' ? 'flex' : 'none';
    livreurField.style.flexDirection = 'column';
  }
  radios.forEach(r => r.addEventListener('change', toggleLivreurField));
  toggleLivreurField();

  // Fenêtre de choix du livreur : petite liste des plus proches +
  // recherche AJAX par nom (débouncée) plutôt qu'un simple <select>.
  const openBtn = document.getElementById('openLivreurModal');
  if (openBtn) {
    const modal = document.getElementById('livreurModal');
    const closeBtn = document.getElementById('closeLivreurModal');
    const searchInput = document.getElementById('livreurSearchInput');
    const resultsList = document.getElementById('livreurResultsList');
    const idInput = document.getElementById('id_livreur');
    const choisiLabel = document.getElementById('livreurChoisiLabel');
    const rechercheUrl = '<?php echo e(route('commandes.livreurs.rechercher', $annonce)); ?>';
    const livreursProches = <?php echo json_encode($livreurs->map(fn ($l) => [
        'id' => $l->id_utilisateur, 'nom' => $l->nom, 'prenom' => $l->prenom) ?>;

    let debounceTimer = null;

    function renderResults(livreurs) {
      resultsList.innerHTML = '';

      if (livreurs.length === 0) {
        resultsList.innerHTML = '<p class="livreur-results-empty">Aucun livreur trouvé.</p>';
        return;
      }

      livreurs.forEach(function (l) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'livreur-option';

        const infosParts = [];
        if (typeof l.distance_km === 'number') infosParts.push(l.distance_km + ' km');
        if (l.moyen_transport) infosParts.push(l.moyen_transport);

        btn.innerHTML = '<span><b></b><span></span></span><i class="fa-solid fa-chevron-right"></i>';
        btn.querySelector('b').textContent = l.nom + ' ' + l.prenom;
        btn.querySelector('span span').textContent = infosParts.join(' · ');

        btn.addEventListener('click', function () {
          idInput.value = l.id;
          choisiLabel.textContent = l.nom + ' ' + l.prenom;
          modal.style.display = 'none';
        });

        resultsList.appendChild(btn);
      });
    }

    function rechercher(q) {
      fetch(rechercheUrl + '?q=' + encodeURIComponent(q), { headers: { 'Accept': 'application/json' } })
        .then(function (r) { return r.json(); })
        .then(function (data) { renderResults(data.livreurs || []); })
        .catch(function () { renderResults([]); });
    }

    openBtn.addEventListener('click', function () {
      modal.style.display = 'flex';
      searchInput.value = '';
      renderResults(livreursProches);
      searchInput.focus();
    });

    closeBtn.addEventListener('click', function () {
      modal.style.display = 'none';
    });

    modal.addEventListener('click', function (e) {
      if (e.target === modal) modal.style.display = 'none';
    });

    searchInput.addEventListener('input', function () {
      const q = searchInput.value.trim();
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(function () {
        if (q.length === 0) {
          renderResults(livreursProches);
        } else {
          rechercher(q);
        }
      }, 300);
    });
  }
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\commandes\create.blade.php ENDPATH**/ ?>