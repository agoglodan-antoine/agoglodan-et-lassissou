<?php $__env->startSection('title', 'Livraisons proposées — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Livraisons proposées</h1>
        <p>Commandes pour lesquelles un acheteur vous a choisi comme livreur — acceptez ou refusez chacune.</p>
      </div>
      <a href="<?php echo e(route('mon-espace.livraison.mes')); ?>" class="btn btn-ghost-dark">Mes livraisons en cours</a>
    </div>

    <div class="dash-card" style="background:<?php echo e($estDisponible ? 'var(--pasture-soft)' : 'rgba(189,74,30,0.08)'); ?>;box-shadow:none;display:flex;align-items:center;justify-content:space-between;gap:16px;">
      <span style="font-weight:600;color:<?php echo e($estDisponible ? 'var(--pasture-dark)' : 'var(--clay-dark)'); ?>;">
        <i class="fa-solid <?php echo e($estDisponible ? 'fa-circle-check' : 'fa-circle-exclamation'); ?>"></i>
        <?php echo e($estDisponible ? 'Vous êtes actuellement disponible selon votre planning.' : "Vous vous êtes déclaré indisponible en ce moment — pensez à refuser les livraisons que vous ne pourrez pas honorer."); ?>

      </span>
      <a href="<?php echo e(route('mon-espace.planning.index')); ?>" class="btn btn-ghost-dark btn-sm">Gérer mon planning</a>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="dash-card" style="background:rgba(189,74,30,0.08);border:none;color:var(--clay-dark);font-weight:600;">
        <?php echo e($errors->first()); ?>

      </div>
    <?php endif; ?>

    <?php if($livraisons->isEmpty()): ?>
      <div class="empty-state">Aucune livraison ne vous est proposée pour le moment.</div>
    <?php else: ?>
      <?php $__currentLoopData = $livraisons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livraison): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="moderation-card">
          <div style="flex:1;">
            <h4 style="margin-bottom:4px;"><?php echo e($livraison->commande->annonce->titre); ?> — <?php echo e($livraison->commande->quantite); ?> unité(s)</h4>
            <div style="font-size:0.85rem;color:var(--ink-soft);margin-bottom:14px;">
              <b>Enlèvement :</b> <?php echo e($livraison->adresse_fournisseur); ?> &nbsp;<i class="fa-solid fa-arrow-right"></i>&nbsp;
              <b>Livraison :</b> <?php echo e($livraison->adresse_client); ?>

            </div>

            <div class="dash-actions" style="align-items:flex-end;">
              <form method="POST" action="<?php echo e(route('mon-espace.livraison.accepter', $livraison)); ?>" style="display:flex;gap:10px;align-items:flex-end;">
                <?php echo csrf_field(); ?>
                <div class="form-field" style="margin-bottom:0;">
                  <label>Vos frais de livraison (FCFA)</label>
                  <input type="number" name="frais_de_livraison" min="0" step="50" required style="width:160px;">
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Accepter</button>
              </form>

              <form method="POST" action="<?php echo e(route('mon-espace.livraison.rejeter', $livraison)); ?>" onsubmit="return confirm('Refuser cette livraison ? Elle sera proposée à un autre livreur disponible.');">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger btn-sm">Refuser</button>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php echo e($livraisons->links()); ?>

    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\livraison\proposees.blade.php ENDPATH**/ ?>