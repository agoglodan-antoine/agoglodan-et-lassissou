<?php $__env->startSection('title', 'Mes versements — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Mes versements</h1>
        <p>Montants reversés par ElevConnect après confirmation de réception d'une commande (commission déduite).</p>
      </div>
    </div>

    <div class="dash-card">
      <?php if($versements->isEmpty()): ?>
        <p class="form-hint">Aucun versement pour l'instant.</p>
      <?php else: ?>
        <div class="table-responsive">
          <table class="dash-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Commande</th>
                <th>Rôle</th>
                <th>Montant net</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $versements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $versement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($versement->date_versement->format('d/m/Y H:i')); ?></td>
                  <td><?php echo e($versement->commande->code_authenticite); ?> — <?php echo e($versement->commande->annonce->titre ?? '—'); ?></td>
                  <td><?php echo e($versement->type_beneficiaire === 'fournisseur' ? 'Fournisseur' : 'Livreur'); ?></td>
                  <td><b><?php echo e(number_format($versement->montant_verser, 0, ',', ' ')); ?> FCFA</b></td>
                  <td><?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $versement->statut_versement,'force' => $versement->statut_versement === 'reussi' ? 'visible' : 'rejetee']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($versement->statut_versement),'force' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($versement->statut_versement === 'reussi' ? 'visible' : 'rejetee')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <div style="margin-top:16px;"><?php echo e($versements->links()); ?></div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\versements\index.blade.php ENDPATH**/ ?>