<?php $__env->startSection('title', 'Mon catalogue — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Mon catalogue</h1>
        <?php ($typeRole = \App\Models\Annonce::typeAttenduPourRole(auth()->user()->role)); ?>
        <p>Publiez, modifiez et suivez le statut de vos annonces <?php echo e($typeRole === 'animal' ? "d'animaux" : 'de '.$typeRole); ?>.</p>
      </div>
      <a href="<?php echo e(route('mon-espace.annonces.create')); ?>" class="btn btn-primary">+ Nouvelle annonce</a>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="dash-card" style="background:rgba(189,74,30,0.08);border:none;color:var(--clay-dark);font-weight:600;">
        <?php echo e($errors->first()); ?>

      </div>
    <?php endif; ?>

    <div class="dash-card" style="padding:0;">
      <?php if($annonces->isEmpty()): ?>
        <div class="empty-state">
          Vous n'avez encore publié aucune annonce.
          <br><a href="<?php echo e(route('mon-espace.annonces.create')); ?>" class="btn btn-ghost-dark" style="margin-top:16px;display:inline-flex;">Publier ma première annonce</a>
        </div>
      <?php else: ?>
        <div class="table-responsive">
<table class="dash-table">
          <thead>
            <tr>
              <th>Annonce</th>
              <th>Prix</th>
              <th>Quantité</th>
              <th>Statut</th>
              <th>Publiée le</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td style="display:flex;align-items:center;gap:12px;">
                  <img class="dash-thumb" src="<?php echo e($annonce->image_1 ? asset('storage/'.$annonce->image_1) : ''); ?>" alt="">
                  <div>
                    <b><?php echo e($annonce->titre); ?></b>
                    <?php if($annonce->statut === 'rejetee' && $annonce->motif_rejet): ?>
                      <div style="font-size:0.78rem;color:var(--clay-dark);">Motif : <?php echo e($annonce->motif_rejet); ?></div>
                    <?php endif; ?>
                  </div>
                </td>
                <td><?php echo e(number_format($annonce->prix_unitaire, 0, ',', ' ')); ?> FCFA</td>
                <td><?php echo e($annonce->quantite); ?></td>
                <td><?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['status' => $annonce->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($annonce->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?></td>
                <td><?php echo e($annonce->date_publication->format('d/m/Y')); ?></td>
                <td>
                  <div class="dash-actions">
                    <a href="<?php echo e(route('mon-espace.annonces.show', $annonce)); ?>" class="btn btn-ghost-dark btn-sm">Voir</a>
                    <a href="<?php echo e(route('mon-espace.annonces.edit', $annonce)); ?>" class="btn btn-ghost-dark btn-sm">Modifier</a>
                    <form method="POST" action="<?php echo e(route('mon-espace.annonces.destroy', $annonce)); ?>" onsubmit="return confirm('Supprimer définitivement cette annonce ?');">
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
</div>
      <?php endif; ?>
    </div>

    <?php echo e($annonces->links()); ?>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\annonces\index.blade.php ENDPATH**/ ?>