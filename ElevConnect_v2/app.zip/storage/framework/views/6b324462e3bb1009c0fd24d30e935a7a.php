<?php $__env->startSection('title', 'Modifier le service — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <div class="auth-card" style="max-width:640px;">
      <?php if (isset($component)) { $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-link','data' => ['href' => route('mon-espace.services.show', $service),'label' => 'Retour au détail du service']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('mon-espace.services.show', $service)),'label' => 'Retour au détail du service']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $attributes = $__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__attributesOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01)): ?>
<?php $component = $__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01; ?>
<?php unset($__componentOriginal5426bd0bea02df2e6dd2a60e50fa4c01); ?>
<?php endif; ?>
      <h1>Modifier le service</h1>

      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('mon-espace.services.update', $service)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="form-field">
          <label for="titre_service">Titre du service</label>
          <input type="text" id="titre_service" name="titre_service" value="<?php echo e(old('titre_service', $service->titre_service)); ?>" required>
        </div>
        <div class="form-field">
          <label for="description">Description</label>
          <textarea id="description" name="description" rows="4"><?php echo e(old('description', $service->description)); ?></textarea>
        </div>
        <div class="form-grid">
          <div class="form-field">
            <label for="prix">Prix (FCFA)</label>
            <input type="number" step="0.01" min="0" id="prix" name="prix" value="<?php echo e(old('prix', $service->prix)); ?>" required>
          </div>
          <div class="form-field">
            <label for="temps_traitement">Durée estimée (minutes)</label>
            <input type="number" min="5" id="temps_traitement" name="temps_traitement" value="<?php echo e(old('temps_traitement', $service->temps_traitement)); ?>" required>
          </div>
          <div class="form-field">
            <label for="statut_service">Disponibilité</label>
            <select id="statut_service" name="statut_service" required>
              <option value="disponible" <?php echo e(old('statut_service', $service->statut_service) === 'disponible' ? 'selected' : ''); ?>>Disponible</option>
              <option value="indisponible" <?php echo e(old('statut_service', $service->statut_service) === 'indisponible' ? 'selected' : ''); ?>>Indisponible</option>
            </select>
          </div>
          <div class="form-field full">
            <label for="photo_illustrative">Remplacer la photo</label>
            <input type="file" id="photo_illustrative" name="photo_illustrative" accept="image/*">
          </div>
        </div>

        <button type="submit" class="btn btn-primary auth-submit">Enregistrer</button>
      </form>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\services\edit.blade.php ENDPATH**/ ?>