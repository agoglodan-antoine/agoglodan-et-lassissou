<?php $__env->startSection('title', 'Créer un compte — ElevConnect'); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-section">
  <div class="container">
    <div class="auth-card" style="max-width:720px;">
      <h1>Créer un compte</h1>
      <p class="sub">Inscription différenciée par type d'acteur — chaque compte enregistre une position GPS captée depuis votre téléphone (recherche par proximité).</p>

      <?php if($errors->any()): ?>
        <div class="form-error" style="margin-bottom:16px;">
          <ul style="margin:0;padding-left:18px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('register')); ?>" id="registerForm">
        <?php echo csrf_field(); ?>

        <div class="role-picker" id="rolePicker">
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="position:relative;">
              <input type="radio" name="role" id="role-<?php echo e($r); ?>" value="<?php echo e($r); ?>" <?php echo e($role === $r ? 'checked' : ''); ?>>
              <label for="role-<?php echo e($r); ?>">
                <?php echo e(match($r) {
                    'eleveur' => 'Éleveur',
                    'acheteur' => 'Acheteur',
                    'vendeur_provende' => 'Vendeur de provende',
                    'vendeur_accessoire' => 'Vendeur d\'accessoires',
                    'veterinaire' => 'Vétérinaire',
                    'livreur' => 'Livreur',
                    default => ucfirst($r),
                }); ?>

              </label>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-grid">
          <div class="form-field">
            <label for="prenom">Prénom</label>
            <input type="text" id="prenom" name="prenom" value="<?php echo e(old('prenom')); ?>" required>
          </div>
          <div class="form-field">
            <label for="nom">Nom</label>
            <input type="text" id="nom" name="nom" value="<?php echo e(old('nom')); ?>" required>
          </div>
          <div class="form-field">
            <label for="email">Adresse email</label>
            <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
          </div>
          <div class="form-field">
            <label for="telephone">Téléphone</label>
            <input type="tel" id="telephone" name="telephone" value="<?php echo e(old('telephone')); ?>">
          </div>
          <div class="form-field">
            <label for="password">Mot de passe</label>
            <input type="password" id="password" name="password" required minlength="8">
          </div>
          <div class="form-field">
            <label for="password_confirmation">Confirmation</label>
            <input type="password" id="password_confirmation" name="password_confirmation" required minlength="8">
          </div>
          <div class="form-field full">
            <label for="adresse">Adresse / zone</label>
            <input type="text" id="adresse" name="adresse" value="<?php echo e(old('adresse')); ?>" placeholder="Ex. Parakou, quartier Banikanni">
          </div>

          
          <div class="form-field role-only" data-for="eleveur">
            <label for="nom_exploitation">Nom de l'exploitation</label>
            <input type="text" id="nom_exploitation" name="nom_exploitation" value="<?php echo e(old('nom_exploitation')); ?>">
          </div>
          <div class="form-field role-only" data-for="vendeur_provende,vendeur_accessoire">
            <label for="nom_boutique">Nom de la boutique</label>
            <input type="text" id="nom_boutique" name="nom_boutique" value="<?php echo e(old('nom_boutique')); ?>">
          </div>
          <div class="form-field role-only" data-for="veterinaire">
            <label for="specialite">Spécialité</label>
            <input type="text" id="specialite" name="specialite" value="<?php echo e(old('specialite')); ?>">
          </div>
          <div class="form-field role-only" data-for="veterinaire">
            <label for="zone_intervention">Zone d'intervention</label>
            <input type="text" id="zone_intervention" name="zone_intervention" value="<?php echo e(old('zone_intervention')); ?>">
          </div>
          <div class="form-field role-only" data-for="livreur">
            <label for="moyen_transport">Moyen de transport</label>
            <input type="text" id="moyen_transport" name="moyen_transport" value="<?php echo e(old('moyen_transport')); ?>" placeholder="Moto, camionnette…">
          </div>
          <div class="form-field role-only" data-for="livreur">
            <label for="zone_couverture">Zone de couverture</label>
            <input type="text" id="zone_couverture" name="zone_couverture" value="<?php echo e(old('zone_couverture')); ?>">
          </div>
          <div class="form-field role-only" data-for="acheteur">
            <label for="type_acheteur">Type d'acheteur</label>
            <select id="type_acheteur" name="type_acheteur">
              <option value="particulier">Particulier</option>
              <option value="professionnel">Professionnel</option>
            </select>
          </div>
        </div>

        <div class="geoloc-status" id="geolocStatus">
          Localisation requise — cliquez sur « Activer ma position » ci-dessous.
        </div>
        <input type="hidden" name="latitude" id="latitude" value="<?php echo e(old('latitude')); ?>">
        <input type="hidden" name="longitude" id="longitude" value="<?php echo e(old('longitude')); ?>">
        <button type="button" class="btn btn-ghost-dark" id="geolocBtn" style="margin-bottom:20px;">
          Activer ma position
        </button>

        <button type="submit" class="btn btn-primary auth-submit" id="submitBtn">Créer mon compte</button>
      </form>

      <p class="auth-switch">Déjà inscrit ? <a href="<?php echo e(route('login')); ?>">Se connecter</a></p>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function(){
  const roleInputs = document.querySelectorAll('input[name="role"]');
  const roleOnlyFields = document.querySelectorAll('.role-only');

  function applyRoleVisibility(){
    const selected = document.querySelector('input[name="role"]:checked')?.value;
    roleOnlyFields.forEach(field => {
      const roles = field.dataset.for.split(',');
      const show = roles.includes(selected);
      field.style.display = show ? 'flex' : 'none';
      field.querySelectorAll('input, select').forEach(el => el.disabled = !show);
    });
  }
  roleInputs.forEach(r => r.addEventListener('change', applyRoleVisibility));
  applyRoleVisibility();

  // Géolocalisation obligatoire à l'inscription (position GPS captée depuis le
  // téléphone — règle transversale du cahier des charges, chap. 3).
  const geolocBtn = document.getElementById('geolocBtn');
  const geolocStatus = document.getElementById('geolocStatus');
  const latInput = document.getElementById('latitude');
  const lngInput = document.getElementById('longitude');
  const submitBtn = document.getElementById('submitBtn');

  submitBtn.addEventListener('click', function(e){
    if (!latInput.value || !lngInput.value) {
      e.preventDefault();
      geolocStatus.textContent = "Veuillez activer votre position avant de créer votre compte.";
      geolocStatus.className = 'geoloc-status err';
    }
  });

  geolocBtn.addEventListener('click', function(){
    if (!navigator.geolocation) {
      geolocStatus.textContent = "La géolocalisation n'est pas disponible sur cet appareil.";
      geolocStatus.className = 'geoloc-status err';
      return;
    }
    geolocStatus.textContent = "Localisation en cours…";
    geolocStatus.className = 'geoloc-status';
    navigator.geolocation.getCurrentPosition(function(pos){
      latInput.value = pos.coords.latitude;
      lngInput.value = pos.coords.longitude;
      geolocStatus.innerHTML = "<i class=\"fa-solid fa-check\"></i> Position activée";
      geolocStatus.className = 'geoloc-status ok';
    }, function(){
      geolocStatus.textContent = "Impossible d'obtenir votre position. Autorisez la géolocalisation puis réessayez.";
      geolocStatus.className = 'geoloc-status err';
    });
  });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\auth\register.blade.php ENDPATH**/ ?>