<?php $__env->startSection('title', 'Modération des annonces — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container">
    <?php echo $__env->make('admin._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="dash-head">
      <div>
        <h1>Modération des annonces</h1>
        <p>Annonces en attente d'approbation avant publication sur le catalogue public.</p>
      </div>
    </div>

    <?php if(session('status')): ?>
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>

    <?php if($annonces->isEmpty()): ?>
      <div class="empty-state"><i class="fa-solid fa-circle-check"></i> Aucune annonce en attente de modération.</div>
    <?php else: ?>
      <?php $__currentLoopData = $annonces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annonce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="moderation-card">
          <img src="<?php echo e($annonce->image_1 ? asset('storage/'.$annonce->image_1) : ''); ?>" alt="">
          <div style="flex:1;">
            <?php if (isset($component)) { $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-pill','data' => ['force' => 'en_attente','label' => ucfirst($annonce->type_annonce)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['force' => 'en_attente','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(ucfirst($annonce->type_annonce))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $attributes = $__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__attributesOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890)): ?>
<?php $component = $__componentOriginal0f0f6d48f1e3fcafba02703e0b070890; ?>
<?php unset($__componentOriginal0f0f6d48f1e3fcafba02703e0b070890); ?>
<?php endif; ?>
            <h4 style="margin:8px 0 4px;"><?php echo e($annonce->titre); ?></h4>
            <div style="font-size:0.85rem;color:var(--ink-soft);margin-bottom:10px;">
              Par <?php echo e($annonce->auteur->nom); ?> <?php echo e($annonce->auteur->prenom); ?> —
              <?php echo e(number_format($annonce->prix_unitaire, 0, ',', ' ')); ?> FCFA —
              publiée le <?php echo e($annonce->date_publication->format('d/m/Y à H:i')); ?>

            </div>
            <?php if($annonce->description): ?>
              <p style="font-size:0.88rem;color:var(--ink-soft);margin-bottom:12px;"><?php echo e(Str::limit($annonce->description, 160)); ?></p>
            <?php endif; ?>

            <div class="dash-actions">
              <form method="POST" action="<?php echo e(route('mon-espace.admin.moderation.approuver', $annonce)); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary btn-sm">Approuver</button>
              </form>
            </div>

            <form method="POST" action="<?php echo e(route('mon-espace.admin.moderation.rejeter', $annonce)); ?>" class="moderation-reject-form">
              <?php echo csrf_field(); ?>
              <input type="text" name="motif_rejet" placeholder="Motif de rejet (obligatoire)" required>
              <button type="submit" class="btn btn-danger btn-sm">Rejeter</button>
            </form>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php echo e($annonces->links()); ?>

    <?php endif; ?>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\admin\moderation\index.blade.php ENDPATH**/ ?>