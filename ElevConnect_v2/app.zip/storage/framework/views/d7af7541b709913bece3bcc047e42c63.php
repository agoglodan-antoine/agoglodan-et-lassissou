<?php $__env->startSection('title', 'Notifications — ElevConnect'); ?>

<?php $__env->startSection('content'); ?>
<section class="dash-section">
  <div class="container" style="max-width:700px;">
    <div class="dash-head">
      <div>
        <h1>Notifications</h1>
        <p>Suivi de vos annonces, commandes, livraisons et rendez-vous.</p>
      </div>
    </div>

    <div class="dash-card" style="padding:0;">
      <?php if($notifications->isEmpty()): ?>
        <div class="empty-state">Aucune notification pour le moment.</div>
      <?php else: ?>
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div style="padding:18px 20px;border-bottom:1px solid var(--line);<?php echo e(! $notif->lu ? 'background:var(--pasture-soft);' : ''); ?>">
            <div><?php echo e($notif->contenu); ?></div>
            <div class="form-hint" style="margin-top:4px;"><?php echo e($notif->date_creation->diffForHumans()); ?></div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>

    <?php echo e($notifications->links()); ?>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.monEspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Memoire\ElevConnect_v2\resources\views\notifications\index.blade.php ENDPATH**/ ?>