@extends('layouts.app')

@section('title', 'Livraisons disponibles — ElevConnect')

@push('styles')
  <link rel="stylesheet" href="{{ asset('css/dashboard.css') }}">
@endpush

@section('content')
<section class="dash-section">
  <div class="container">
    <div class="dash-head">
      <div>
        <h1>Livraisons disponibles</h1>
        <p>Commandes validées par leur fournisseur, en attente d'un livreur.</p>
      </div>
      <a href="{{ route('livraison.mes') }}" class="btn btn-ghost-dark">Mes livraisons en cours</a>
    </div>

    @if (session('status'))
      <div class="dash-card" style="background:var(--pasture-soft);border:none;color:var(--pasture-dark);font-weight:600;">
        {{ session('status') }}
      </div>
    @endif
    @if ($errors->any())
      <div class="dash-card" style="background:rgba(189,74,30,0.08);border:none;color:var(--clay-dark);font-weight:600;">
        {{ $errors->first() }}
      </div>
    @endif

    @if ($livraisons->isEmpty())
      <div class="empty-state">Aucune livraison disponible pour le moment.</div>
    @else
      @foreach ($livraisons as $livraison)
        <div class="moderation-card">
          <div style="flex:1;">
            <h4 style="margin-bottom:4px;">{{ $livraison->commande->annonce->titre }} — {{ $livraison->commande->quantite }} unité(s)</h4>
            <div style="font-size:0.85rem;color:var(--ink-soft);margin-bottom:14px;">
              <b>Enlèvement :</b> {{ $livraison->adresse_fournisseur }} &nbsp;→&nbsp;
              <b>Livraison :</b> {{ $livraison->adresse_client }}
            </div>

            <form method="POST" action="{{ route('livraison.accepter', $livraison) }}" style="display:flex;gap:10px;align-items:flex-end;">
              @csrf
              <div class="form-field" style="margin-bottom:0;">
                <label>Vos frais de livraison (FCFA)</label>
                <input type="number" name="frais_de_livraison" min="0" step="50" required style="width:160px;">
              </div>
              <button type="submit" class="btn btn-primary btn-sm">Accepter cette livraison</button>
            </form>
          </div>
        </div>
      @endforeach

      {{ $livraisons->links() }}
    @endif
  </div>
</section>
@endsection
